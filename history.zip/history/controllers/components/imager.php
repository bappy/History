<?php
class ImagerComponent extends Object {
    var $components = array('RequestHandler','SimpleHtmlDomBaked');
    var $helpers = array('Javascript', 'Ajax','CustomDate',"Js");
    function valid_url($url)
    {


        $ch = @curl_init($url);

        @curl_setopt($ch, CURLOPT_HEADER, TRUE);
        @curl_setopt($ch, CURLOPT_NOBODY, TRUE);
        @curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE);
        @curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

       if(preg_match('/HTTP\/.* ([0-9]+) .*/', @curl_exec($ch)))
                  return true;
       else return false;



        }

    function check_ajax($url)
    {
        // $this->autoRender = false;

          $valid= $this->valid_url($url);




            if($valid)
            {



                    $html = $this->SimpleHtmlDomBaked;
                    $html->curl_and_load($url, true);
                    if($html->find('.image' ))
                    {
                        $image= $html->find('a.image img', 0)->src;
                        if(isset($image))
                        {

                            return $image;
                        }

                    }
                    else return false;



                }

                return false;

        }



}
?>
