<?php
include("headline_events_controller.php");
class HeadlineQuotesController extends HeadlineEventsController {

	var $name = 'HeadlineQuotes';
    var $components = array('RequestHandler','Imager','readimage');
    var $uses=array("HeadlineQuote","HeadlineEvent");
    var $helpers = array('Javascript', 'Ajax','CustomDate','Js' => array('Jquery'),"Utility");

    var $paginate = array(
        'limit' => 5
    );
    function  autoComplete()
    {
       /* $this->layout = 'ajax';
        $this->loadModel('Link');
        $terms = $this->Link->find('all', array(
            'conditions' => array(
                'Link.name LIKE' => $this->params['url']['autoCompleteText'].'%'
            ),
            'fields' => array('url'),
            'limit' => 3,
            'recursive'=>-1,
        ));
        $terms = Set::Extract($terms,'{n}.Link.url');
        $this->set('terms', $terms);
       */
        $this->layout = 'ajax';
        $this->loadModel('Link');

        $terms = $this->Link->find('all', array(
            'conditions' => array(
                'Link.name LIKE' => $this->params['form']['queryString'].'%'
            ),
            'fields' => array('name','url','id'),
            'limit' => 10,
            'recursive'=>-1,
        ));

        $this->set('terms', $terms);

    }
function wikiview()
{

    if (!empty($this->params['requested'])) {
        $url=$this->params;


        $url=$this->params["pass"][0];


        if(!empty($url))
        {

            $url= $this->Imager->check_ajax($url);


            return $url;
                 //$this->set("url",$url);
           }

        }


    }


    function  wiki_links_db()
    {
        //Configure::write('debug', 0);
        $this->layout = 'ajax';



        if (($this->RequestHandler->isAjax()&&(!empty($this->params["form"]["url"]))))
        {

          $id=$this->params["form"]["url"];
            $this->loadModel('Link');

            $terms = $this->Link->find('all', array(
                'conditions' => array(
                    'Link.id' => $id
                ),
                'fields' => array('url','imageurl'),

            ));


            $this->set('terms', $terms);


        }

    }



    function  weki_links()
    {
      Configure::write('debug', 0);
        $this->layout = 'ajax';
       // $this->autoRender = false;


        if (($this->RequestHandler->isAjax()&&(!empty($this->params["form"]["url"]))))

        {
            /*If link exists*/

            if(isset($this->params["form"]["id"]))
            {
                $this->loadModel("Link");
                $id=$this->params["form"]["id"];
           $image=$this->Link->read("imageurl",$id);
            /*If link exists*/
            if(!empty($image["Link"]["imageurl"]))
            {
                $this->set("url",$image["Link"]["imageurl"]);
            }
            }

else
{


          $url=$this->params["form"]["url"];
            if(!empty($url))
            {
          $url= $this->Imager->check_ajax(trim($url));
            if(!$url)
            $this->set("url","0");
            else $this->set("url",$url);
            }
}
           /* App::import('Vendor', 'amazon/S3');
            $s = new S3('qpEPv/3/lQCL3g8/nQ211sEvRlkTs+31RMlLNq4w', 'AKIAJUC5LOYP6CUM5FGQ');

           if($s->putObject('my-own-bucket/myobject','somedata'))
           {
                echo "We successfully uploaded your file.";



            }

           */
        }
    }
       function  HeadlineQuotes()
       {
           //error handler;
           $this->Session->setFlash(__("Ajax error occurred please remove the '/' ", true));
           $this->redirect(array('action' => 'index'));
       }
    function beforeFilter(){

       // HeadlineEventsController::check_db();

    }

    function index() {

		$this->Headline->HeadlineQuote->Event->recursive =3;
		$this->set('headlineQuotes', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid headline quote', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('headlineQuote', $this->HeadlineQuote->read(null, $id));
	}

   /* function sort_order()
    {

        if($this->params['isAjax'])
        {
            $this->layout="ajax";
            debug($this->params["form"]);

        }
    }
   */
    function  parse($uri)
    {
       $rURL=explode('/',$uri);
      $month=$rURL[count($rURL)-1];
      $day=$rURL[count($rURL)-2];

       $month=explode(':',$month);
       $day=explode(':',$day);
       $array["day"]=$day[1];
        $array["month"]=$month[1];

        return $array;

    }

    function  get_date($data,$params)
     {


        if($params['isAjax'])
        {




            if(((isset($params["form"]["month"]))||(isset($params["form"]["day"]))))
            {
                $month=$params["form"]["month"];
                $day=$params["form"]["day"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;


            }
            else{
                $day=$this->params["named"]["day"];
                $month=$this->params["named"]["month"];



            }
            $array["day"]=$day;
            $array["month"]=$month;
            return $array;

        }
        else
        {  //not ajax
            if(!empty($data))
            {


                $month=$data["HeadlineQuote"]["month"];
                $day=$data["HeadlineQuote"]["day"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;



            }
            else if(!empty($params["named"]))
            {
                  $day=$params["named"]["day"];
                 $month=$params["named"]["month"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;
            }
            else {
                $today=  date("d:m");
                $today=explode(":",$today);
                $day=$today[0];
                $month=$today[1];
            }




        }

        $array["day"]=$day;
        $array["month"]=$month;

        return $array;
    }

    function checkhttp($url)
    {
       if(empty($url))
        return $url;
        //die($url[0]);

        if((strtolower($url[0])=="h")&&(strtolower($url[1])=="t")&&(strtolower($url[2])=="t")&&(strtolower($url[3])=="p")&&(strtolower($url[4])==":"))
        {
            return $url;
        }

        $count=0;

       for($i=0;$i<strlen($url);$i++)
       {
           if($url[$i]=='/')
                   $count++;
       }

        if($count==3)
        {

           // return 'http://'.$_SERVER['HTTP_HOST'].'/headlne'.'/img/no_pic.png';
 return "http://today_in_history.s3.amazonaws.com/no_photo";
        }
        if(isset($url))
        if($url[0]=='/')
        $url=ltrim($url,"/");
        if($url[0]=='/')
         $url=ltrim($url,"/");
        return "http://".$url;
    }
    function w3amazonURL($url)
    {
        $info=$this->readimage->url_extension($url);
        if(empty($info["filename"]))
          return $url;
        $image=$this->readimage->uploadImage($url,$info);
        if($image["upload"])
        {

            return $image["url"];
        }
    }

	function add($M='',$D='') {



        if($this->params['isAjax']){
                  $this->layout="ajax";

            $day=$this->params["form"]["day"];
           $month=$this->params["form"]["month"];
            $this->set(compact('day',$day));
            $this->set(compact('month',$month));
        }

        else if(!empty($D)&&!(empty($M)))
        {
            $day=$D;
            $month=$M;
        }
        else
        {
        $UDate= $this->get_date($this->data,$this->params) ;

         $day='';
         $month='';
         $day=$UDate["day"];
         $month=$UDate["month"] ;
        }
        $this->set(compact('day',$day));
        $this->set(compact('month',$month));


        $this->loadModel('Event');
        $this->loadModel('Headline');
        $this->loadModel("HeadlineQuote");

      $hID=$this->data["HeadlineQuote"]["headline_id"];
       $hID=$this->HeadlineQuote->find("first",array("conditions"=>array("day"=>$day,"month"=>$month)));
       $hID=($hID["HeadlineQuote"]["id"]);

       if(!empty($hID))
           $this->HeadlineQuote->id=$hID;
        if (!empty($this->data)&&(empty($hID))) {
           if(!empty($this->data["HeadlineQuote"]["s3amazon"]))
         //$this->data["HeadlineQuote"]["s3amazon"]=$this->w3amazonURL($this->checkhttp($this->data["HeadlineQuote"]["s3amazon"]));
			$this->HeadlineQuote->create();
			if ($this->HeadlineQuote->save($this->data)) {
				$this->Session->setFlash(__('The headline quote has been saved', true));
				//$this->redirect(array('action' => 'index'));
                //$this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add',"day"=>$day,"month"=>$month));
			} else {
				$this->Session->setFlash(__('The headline quote could not be saved. Please, try again.', true));
			}
		}
        else if (!empty($this->data)&&(!empty($hID)))
        {
            if(empty($this->data["HeadlineQuote"]["s3amazon"]))
            {
            /*$this->data["HeadlineQuote"]["s3amazon"]=false;
                $data = array(
                    'HeadlineQuote' => array(
                        'id'          =>    $hID,
                        'month'   =>    $this->data["HeadlineQuote"]["month"],
                        'author_name'=>$this->data["HeadlineQuote"]["author_name"],
                        'quote'=>$this->data["HeadlineQuote"]["quote"],
                        'link'=>$this->data["HeadlineQuote"]["link"],
                        'day'=>$this->data["HeadlineQuote"]["day"]

                    )
                );
            */
                if($this->HeadlineQuote->save( $this->data, false, array('month','day','quote','link','s3amazon','author_name') ))
                    $this->Session->setFlash(__('The headline quote has been Updated', true));

             }
            else
            {

                if ($this->HeadlineQuote->save($this->data)) {

                $this->Session->setFlash(__('The headline quote has been Updated', true));
                //$this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add'));



                }

            }
        }


        $this->Event->recursive =-1;
        $this->Headline->recursive =-1;

        $event_headline=$this->Headline->find("all",array("conditions"=>array('AND' =>array("Headline.day"=>$day,"Headline.month"=>$month)),"order"=>"Headline.order ASC, Headline.time Desc","limit"=>5));
        //$event_headline=$this->Headline->find("all",array('AND' =>array("Headline.day"=>$day,"Headline.month"=>$month),"order"=>array("Headline.order ASC, Headline.time Desc"),"limit"=>5));
        if(isset($event_headline[0]["Headline"]["id"]))
        $headID=$event_headline[0]["Headline"]["id"];
        if(empty($headID))
          $headID=$this->data["HeadlineQuote"]["headline_id"];

        $events=  $this->findEvent($day,$month,36);
        $births = $this->findEvent($day,$month,37);
        $deaths = $this->findEvent($day,$month,38);
        $holidays = $this->findEvent($day,$month,39);

        $qinfo=array();
        $this->HeadlineQuote->recursive =-1;
        //if(!empty($headID))
        $qinfo=$this->HeadlineQuote->find("first",array("conditions"=>array('AND' =>array("HeadlineQuote.day"=>$day,"HeadlineQuote.month"=>$month))));

        $this->set(compact('qinfo'));
        $this->set(compact('events'));
        $this->set(compact("event_headline"));
        $this->set(compact('births'));

        $this->set(compact('deaths'));
        $this->set(compact('holidays'));


	}


    function findEvent($day,$month,$category)
    {
       // $this->Event->unBindModel(array("User"));

        $this->loadModel('Event');
        $this->Event->unbindModel(
            array('belongsTo' => array('User'))
        );

        $this->Event->unbindModel(
            array('belongsTo' => array('Category'))
        );
       $this->recursive=-1;
        $options['joins'] = array(
            array('table' => 'headlines',
                'alias' => 'Headline',
                'type' => 'Left',
                'fields'=>array("Event.name"),
                'conditions' => array(
                   'Event.id=Headline.headline_quote_id'
                )
            )
        );



      //  $this->loadModel("HeadlineEvent");
        $options['conditions']=array('AND'=>array("Event.category_id"=>$category,"Event.day"=>$day,"Event.month"=>$month,"Headline.headline_quote_id"=>null,"Event.status"=>1)) ;
        $options['order']=array('Event.year DESC');
        $events = $this->Event->find('all', $options);

        return $events;
    }



    function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid headline quote', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->HeadlineQuote->save($this->data)) {
				$this->Session->setFlash(__('The headline quote has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The headline quote could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->HeadlineQuote->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for headline quote', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->HeadlineQuote->delete($id)) {
			$this->Session->setFlash(__('Headline quote deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Headline quote was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}


    function items()
    {
        //Configure::write('debug', 0);


        if($this->params['isAjax']){

            $this->layout="ajax";
            $day=$this->params["form"]["day"];
            $month=$this->params["form"]["month"];


        $events=  $this->findEvent($day,$month,36);
        $births = $this->findEvent($day,$month,37);
        $deaths = $this->findEvent($day,$month,38);
        $holidays = $this->findEvent($day,$month,39);

        $this->set(compact('day'));
        $this->set(compact('month'));
        $this->set(compact('events'));
        $this->set(compact('births'));
        $this->set(compact('deaths'));
        $this->set(compact('holidays'));
        }

    }


}