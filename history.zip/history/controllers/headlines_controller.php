<?php
class HeadlinesController extends AppController
{

    var $name = 'Headlines';
    var $uses = array("Headline", "Event");
    var $components = array('RequestHandler');
    // var $uses=array("HeadlineQuote");
    var $helpers = array('Javascript', 'Ajax', 'CustomDate', "Js");

    function sort_order()
    {
        if ($this->params['isAjax']) {
            $this->layout = "ajax";

            $this->autoRender = false;


            $arr = $this->params["form"]["sortable2"];
            //debug($arr);
            //$arr=$arr["sortable"];
            foreach ($arr as $key => $a) {
                $this->Headline->recursive = -1;
                // $id=$this->Headline->find('first', array('conditions' => array('Headline.headline_quote_id' =>$a )),array("fields=Headline.id")); //array of conditions
                //array of field names
                $id = $this->Headline->findByHeadlineQuoteId($a);
                $this->Headline->id = $id["Headline"]["id"];
                $this->Headline->set("order", $key);
                $this->Headline->save();
            }
        }
    }

    function index()
    {
        if (!empty($this->params['requested'])) {

            $event = ($this->Event->read("event", $this->params["pass"]));
            return ($event["Event"]["event"]);
        }
        else {
            $this->Headline->recursive = 0;
            $this->set('headlines', $this->paginate());
        }
    }

    function event_name()
    {
        if (!empty($this->params['requested'])) {

            $event = ($this->Event->read("name", $this->params["pass"]));
            return ($event["Event"]["name"]);
        }

    }

    function view($id = null)
    {
        if (!$id) {
            $this->Session->setFlash(__('Invalid headline', true));
            $this->redirect(array('action' => 'index'));
        }
        $this->set('headline', $this->Headline->read(null, $id));
    }

    function  inarray($str, $array)
    {
        $counter = 0;

        foreach ($array as $arr) {


            if ($arr == $str) {


                if ($counter === 1)
                    return false;
                else
                    $counter++;

            }


        }

        return true;

    }

    function  Cexists($data)
    {
        if (empty($data))
            return false;

        if (strpos($data["Headline"]["category"], ":")) {
            $array = explode(":", $data["Headline"]["category"]);
            if (!$this->inarray($data["Headline"]["headline_quote_id"], $array)) {

                return false;
            }
            else {
                return true;
            }

        }
        else return true;
    }

    function saveData($params)
    {
        $data["Headline"]["headline_quote_id"]=$params["form"]["eid"];
        $data["Headline"]["category_id"]=$params["form"]["cat"];
        $data["Headline"]["day"]=$params["form"]["day"];
        $data["Headline"]["month"]=$params["form"]["month"];
        $data["Headline"]["order"]=0;
        $data["Headline"]["time"]=time();
        $this->Headline->create();
        $this->Headline->save($data);
    }

    function add()
    {

        if ($this->params['isAjax']) {
            $this->layout = "ajax";
           if(!$this->Headline->find('count', array('conditions' => array('Headline.headline_quote_id' =>$this->params["form"]["eid"] ))))
           {
           $this->saveData($this->params) ;

           }
            else
            {
            $duplicate=1;
            $this->set(compact("duplicate"));
            }
            $day= $this->params["form"]["day"];
            $month=$this->params["form"]["month"];
            //$event_headline=$this->Headline->find("all",array("conditions"=>array('AND' =>array("Headline.day"=>$this->params["form"]["day"],"Headline.month"=>$this->params["form"]["month"])),"order"=>array("Headline.order ASC, Headline.time Desc"),"limit"=>5));
            $event_headline=$this->Headline->find("all",array("conditions"=>array('AND' =>array("Headline.day"=>$day,"Headline.month"=>$month)),"order"=>"Headline.order ASC, Headline.time Desc","limit"=>5));
            //$event_headline=$this->Headline->find("all",array('AND' =>array("Headline.day"=>$this->params["form"]["day"],"Headline.month"=>$this->params["form"]["month"]),"order"=>"Headline.order ASC, Headline.time Desc","limit"=>5)) ;
            $this->set(compact("event_headline"));
            $this->set(compact("day"));
            $this->set(compact("month"));
        }
     /*  $day='';
      $month='';
       if(isset($this->data["Headline"]["day"]))
        $day = $this->data["Headline"]["day"];
        if(isset($this->data["Headline"]["month"]))
        $month = $this->data["Headline"]["month"];
        if(!empty($this->data))
        {
        if ($this->Cexists($this->data)) {

            $category_id = $this->data["Headline"]["category_id"];
            $day = $this->data["Headline"]["day"];
            $month = $this->data["Headline"]["month"];
            $this->Headline->id = null;
            $this->data["Headline"]["order"] = "0";
            $this->data["Headline"]["time"] = time();

            $this->Headline->create();
            if ($this->Headline->save($this->data)) {
                $this->Session->setFlash(__('The headline has been saved', true));
                $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add', "day" => $day, "month" => $month));
            } else {
                $this->Session->setFlash(__('The headline could not be saved. Please, try again.', true));
                $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add', "day" => $day, "month" => $month));
            }


        }
        else
        {
            $this->Session->setFlash(__('The headline could not be saved. Please, try again.May be duplicate entry', true));
            if(!empty($day)&&(!empty($month)))
                $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add', "day" => $day, "month" => $month));
            else
                $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add'));
        }

        }//!empty this->data
        if(!empty($day)&&(!empty($month)))
            $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add', "date" => $day, "month" => $month));
        else
        $this->redirect(array('controller' => 'HeadlineQuotes', 'action' => 'add'));
       */
    }

    function edit($id = null)
    {
        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid headline', true));
            $this->redirect(array('action' => 'index'));
        }
        if (!empty($this->data)) {
            if ($this->Headline->save($this->data)) {
                $this->Session->setFlash(__('The headline has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The headline could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {
            $this->data = $this->Headline->read(null, $id);
        }
        $headlineQuotes = $this->Headline->HeadlineQuote->find('list');
        $this->set(compact('headlineQuotes'));
    }

    function delete($id = null) {
        if($this->params['isAjax']){
            $this->layout="ajax";


            $id=$this->params["form"]["id"];
            $day=$this->params["form"]["day"];
            $month=$this->params["form"]["month"];
            $id = $this->Headline->findByHeadlineQuoteId($id);
            $id = $id["Headline"]["id"];

            if (!$id) {
              //  $this->Session->setFlash(__('Invalid id for headline quote', true));
                //		$this->redirect(array('action'=>'index'));
            }
            if ($this->Headline->delete($id)) {
                //$this->Session->setFlash(__('Headline quote deleted', true));
                $this->Headline->recursive = -1;
                $event_headline=$this->Headline->find("all",array("conditions"=>array('AND' =>array("Headline.day"=>$day,"Headline.month"=>$month)),"order"=>"Headline.order ASC, Headline.time Desc","limit"=>5));

                //		$this->redirect(array('action'=>'index'));
                $this->set(compact("event_headline"));
                $this->set(compact("day"));
                $this->set(compact("month"));
            }
            //$this->Session->setFlash(__('Headline quote was not deleted', true));
            //	$this->redirect(array('action' => 'index'));
        }
    }
}
