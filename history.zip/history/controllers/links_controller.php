<?php
class LinksController extends AppController {

    var $name = 'Links';
    var $helpers = array('Html', 'Form', 'Ajax', 'Time', 'Complete');
    var $components = array('RequestHandler','Imager','readimage');
    function w3amazonURL($url)
    {
        $info=$this->readimage->url_extension($url);

        if(empty($info["filename"]))
            return $url;
        $image=$this->readimage->uploadImage($url,$info);


        if($image["upload"])
            return $image["url"];
    }

    function index($id = 0) {

        $links = $this->Session->read('links');

        $this->set('links', $links);
        $this->set('User', $this->User);

        $this->set('_foreignKey', $id);
    }

    function add() {

        if (!empty($this->data))
        {
            $this->Link->set($this->data);

            if($this->Link->validates())
            {
                $links = $this->Session->read('links');
                $links[] = $this->data;
                $this->set('links', $links);

                $this->Session->write('links', $links);
                $this->Session->setFlash(__('Link Added', 'default', array('class' => 'success')));
                $this->redirect( $this->Session->read('link_url') );
            }

        }
        else
        {
            $this->data['Link']['url'] = "http://www.";
        }

    }

    function delete($id = null) {

        $links = $this->Session->read('links');
        $current = 0;
        $newLinks = array();

        foreach ($links as $link){

            if ($current != $id)
            {
                $newLinks[] = $link;
            }
            $current++;
        }

        $this->Session->write('links', $newLinks);
        $this->set('links', $newLinks );

        $this->Session->setFlash(__('Link deleted', 'default', array('class' => 'success')));

        $this->redirect( $this->Session->read('link_url') );
    }

    //======================================================================
    //Service Functions
    //======================================================================

    function service_addWiki() {

        $this->setupJSON();

        /**/
        $jsonData = $this->params['form']['json'];
        $jsonData = json_decode( $jsonData , true );


        $url = $jsonData["url"];

        if(array_key_exists('name', $jsonData))
            $name = $jsonData["name"];
        else
            $name = null;

        $name = str_replace("/wiki/", "", $name);
        $pos = strpos($name, "?");
        if($pos === false)
        {
            $url = "http://en.wikipedia.org/wiki/" . $name ;
            $name = str_replace("_", " ", $name);
        }
        else
        {
            $url = "http://en.wikipedia.org/wiki/" . $name ;
            $name = str_replace("_", " ", $name);
        }

        //$url = "http://en.wikipedia.org/wiki/Ettore_Sottsass";
        //$name = "Ettore_Sottsassa";

        $saved = $this->Link->alreadySaved($url);
        if($saved)
        {
            $results['Results'] = "Success";
            $results['Link'] = $saved;
        }
        else
        {
            $data = array(
                'Link' => array(
                    'url' => $url,
                    'name' => $name
                )
            );

            //Debugger::dump($data['Link']);

            $this->Link->set($data);
            //if($this->Link->validates())
            $saveResult = $this->Link->save($data);
            if($saveResult)
            {
                //$data['Link']['id'] = 999;
                $data['Link']['id'] = $this->Link->id;
                $results['Results'] = "Success";
                $results['Link'] = $data['Link'];
            }
            else
            {
                $results['Results'] = "Fail";
            }

        }
        //Debugger::dump($results);

        $this->set('results', $results);
    }

    function service_add() {

        $this->setupJSON();

        /**/
        $jsonData = $this->params['form']['json'];
        $jsonData = json_decode( $jsonData , true );


        $url = $jsonData["url"];
        //$url = substr($url, 0, strpos($url, "?"));

        //Debugger::dump($jsonData);
        if(array_key_exists('name', $jsonData))
            $name = $jsonData["name"];
        else
            $name = null;

        //$url = "http://www.pacoequip.com/";
        //$name = "Pacific American Commercial Company, PACO, paco";

        $saved = $this->Link->alreadySaved($url);
        if($saved)
        {
            $results['Results'] = "Success";
            $results['Link'] = $saved;
        }
        else
        {
            $data = array(
                'Link' => array(
                    'url' => $url,
                    'name' => $name
                )
            );

            //Debugger::dump($data['Link']);

            $this->Link->set($data);
            //if($this->Link->validates())
            $saveResult = $this->Link->save($data);
            if($saveResult)
            {
                //$data['Link']['id'] = 999;
                $data['Link']['id'] = $this->Link->id;
                $results['Results'] = "Success";
                $results['Link'] = $data['Link'];
            }
            else
            {
                $results['Results'] = "Fail";
                $results['name'] = $name;
                $results['url'] = $url;
            }
        }


        $this->set('results', $results);
    }


    function edit($id = null) {


       if(!empty($this->params["url"]["uid"]))
       {
           $uid=$this->params["url"]["uid"];
           $this->set(compact('uid'));
       }
        else if(isset($this->data["Link"]["uid"]))
        {
        $uid=($this->data["Link"]["uid"]);

        }
        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid event', true));
            $this->redirect(array("controller"=>"Events",'action' => 'index'));
        }
        if (!empty($this->data)) {
               // debug($this->data["Link"]);

            $this->data["Link"]["id"]=$id;
            $this->data["Link"]["imageurl"]=$this->data["Link"]["imageurl"];
            //$this->data["Link"]["imageurl"]=);
            if ($this->Link->save($this->data)) {
                $this->Session->setFlash(__('The event has been saved', true));
               // $this->redirect($this->referer());

                $this->redirect("/Events/edit/".$uid);
                //$this->redirect(array("controller"=>"Events",'action' => 'index'));
            } else {
                $this->Session->setFlash(__('The event could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {

            $this->data = $this->Link->read(null, $id);

        }

    }



    function  get_link_name()
    {
        //  $comments = $this->Event->find('first', array('id' => 'Comment.created DESC', 'limit' => 10));
        if (!empty($this->params['requested'])) {
            $params=($this->params['pass'][0]);
            //debug($this->params);
            $this->Link->recursive=-1;
            $info = $this->Link->find('first',array('conditions'=>array('id' =>$params)));

            return($info["Link"]["name"]);
            //return $info;
        }

    }

    function  add_links()
    {


      /*  if (($this->RequestHandler->isAjax()&&(!empty($this->params["form"]["queryString"])))) {
            $queryString = $this->params["form"]["queryString"];

            // Is the string length greater than 0?
            if(strlen($queryString) >0) {
                $this->Link->recursive=-1;
               $query=$this->Link->find("all",array('limit' =>10,'conditions'=>array('Link.name LIKE' =>$queryString.'%')));

                if($query) {
                    $this->set('info', $query );

                }
             else {
                 $this->set('string', $queryString );
            }
         }
    }
        else {
            echo 'There should be no direct access to this script!';
        }
      */

       $this->set('info', $this->Link->find('all', array(
            'conditions' => array(
                'Link.name LIKE' =>$this->params['url']['q'].'%'
            ),
            'fields' => array('name','url','id')
        )));

    //    $this->set('info',$this->params['url']['q']);
        $this->layout = 'ajax';
    }
    function add_edit_links()
    {


        $eid=$this->params["pass"][0];

           $this->set('info', $this->Link->find('all', array(
                'conditions' => array(
                    'Link.name LIKE' =>$this->params['url']['q'].'%'
                ),
                'fields' => array('name','url','id')
            )));

            $this->set('eid',$eid);
            $this->layout = 'ajax';

        }




    function read_url()
    {

        $this->layout = 'ajax';


    if(($this->params["isAjax"]))
    {

    $id=$this->params["form"]["id"];

    $url = $this->Link->read('url',$id);

        $this->set(compact('url'));
    }

    }


    function read_image()
    {

        $this->layout = 'ajax';


        if(($this->params["isAjax"]))
        {

            $id=$this->params["form"]["id"];

            $url = $this->Link->read('imageurl',$id);



            $this->set(compact('url'));
        }

    }

    function check_url()
    {


       // $url2=$url;
      if($this->params['isAjax'])
      {


          $this->layout = 'ajax';
    $url=$this->params["form"]["url"];

     //  $this->set('new',"http:".$this->Imager->check_ajax($url2));
    $this->set('new',$this->w3amazonURL("http:".$this->Imager->check_ajax(trim($url))));
      }


    }

function headline_image()
{
    if($this->params['isAjax'])
    {
        $this->debug=false;
    $this->layout = 'ajax';
    $url=$this->params["form"]["url"];
    $name=$this->params["form"]["name"];
   if($this->search_duplicate($url))
   {
       $this->set('db',2);
      $data["id"]=NULL;
       $data["imageurl"]=$this->w3amazonURL("http:".$this->Imager->check_ajax($url));
       $data["name"]=$name;
       $data["url"]=$url;


       if(!empty( $data["imageurl"]))
       {
           $this->Link->create();

          if($this->Link->save($data))
           $this->set('new',$data["imageurl"]);
          // else $this->set('new',$data["imageurl"]);

       }

    }
    else  $this->set('db',3); //select from dropdown already exits in DB.

    }

}
    function search_duplicate($url)
    {

        $info = $this->Link->find('count', array('conditions' => array('Link.url' =>trim($url))));

        if(!$info) //no link
            return true;
        return false;
    }



    function addImage()
    {

        $this->autoRender = FALSE;
        $conditions=array("(Link.imageurl)"=>"");
       $info=$this->Link->find("all",array('conditions' => $conditions,'limit' =>10));
        $log = $this->Link->getDataSource()->getLog(false, false);
        debug($log);
        foreach($info as  $information)
        {
            set_time_limit(0);
            $url= $information["Link"]["url"];
            $id=$information["Link"]["id"];
            $image_url=$information["Link"]["imageurl"];



               // echo $image_url;
      $this->Link->id=$id;
                echo $url.'\n';
                if($this->Imager->check_ajax(trim($url)))
    $this->Link->saveField("imageurl",$this->w3amazonURL("http:".$this->Imager->check_ajax(trim($url))));

        }


}



}
?>