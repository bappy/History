<?php
class HeadlineEventsController extends AppController {

	var $name = 'HeadlineEvents';
    var $components = array('RequestHandler');
    // var $uses=array("HeadlineQuote");
    var $helpers = array('Javascript', 'Ajax','CustomDate',"Js");

    function add_custom($data)
    {
        $this->HeadlineEvent->create();
        $this->HeadlineEvent->save($data);


    }

	function index() {
		$this->HeadlineEvent->recursive = 0;
		$this->set('headlineEvents', $this->paginate());
	}

    /*function check_db(){



        $this->loadModel("Event");
        $this->loadModel("HeadlineEvent");
        $options['joins'] = array(
            array('table' => 'events',
                'alias' => 'Event',
                'type' => 'inner',
                'conditions' => array(
                    'event_id=Event.id',

                )
            )
        );

        $event_counter=$this->Event->find("count");
        $headline_counter=$this->HeadlineEvent->find("count",$options);

        if($event_counter<>$headline_counter)
        {
            $options['joins'] = array(
                array('table' => 'headline_events',
                    'alias' => 'HeadlineEvent',
                    'type' => 'inner',
                    'conditions' => array(
                        'event.id=HeadlineEvent.event_id',

                    )
                ));
         $this->Event->recursive=-1;
         $list=$this->Event->find("list",$options);
         $ful_array=$this->Event->find("list");
         $full_array=$this->convert_to_array($ful_array);
         $list=$this->convert_to_array($list);

           $result=array_diff($full_array,$list);

          foreach($result as $key=>$r)
            {

                $data["HeadlineEvent"]["order"]=0;
                $data["HeadlineEvent"]["event_id"]=$r;
                $data["HeadlineEvent"]["type"]="items";
                $this->add_custom($data);

            }
        }

    }


    function  convert_to_array($list)
    {
        $array=array();

        foreach($list as $key=>$l)
        {
            $array[]=$key;
        }

        return $array;
    }


    function sort_order()
    {

       if($this->params['isAjax'])
        {
            $this->layout="ajax";
            Configure::write('debug',0);
            $this->autoRender = false;


        $arr=$this->params["form"];


       foreach($arr["sortable"] as $i=>$array)
        {


         // echo $array.'--------'.$i;


            $data["HeadlineEvent"]["order"]=$i;
            $data["HeadlineEvent"]["event_id"]=$array;

//echo($this->HeadlineEvent->find("count",array('conditions' => array('HeadlineEvent.event_id' =>$array))));
            if($this->HeadlineEvent->find("count",array('conditions' => array('HeadlineEvent.event_id' =>$array))))
            {
              $this->HeadlineEvent->recursive=-1;
             $idr=$this->HeadlineEvent->find("first",array('conditions' => array('HeadlineEvent.event_id' =>$array)));

                $idr=($idr["HeadlineEvent"]["id"]);
              //echo $idr;
                $this->HeadlineEvent->id=$idr;
                $this->HeadlineEvent->save($data);
             }
            else
            {
                $this->HeadlineEvent->create();
                $this->HeadlineEvent->save($data);


            }


        }

        }

    }
    */

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid headline event', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('headlineEvent', $this->HeadlineEvent->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->HeadlineEvent->create();
			if ($this->HeadlineEvent->save($this->data)) {
				$this->Session->setFlash(__('The headline event has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The headline event could not be saved. Please, try again.', true));
			}
		}
		$events = $this->HeadlineEvent->find('list');
		$this->set(compact('events'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid headline event', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->HeadlineEvent->save($this->data)) {
				$this->Session->setFlash(__('The headline event has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The headline event could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->HeadlineEvent->read(null, $id);
		}
		$events = $this->HeadlineEvent->Event->find('list');
		$this->set(compact('events'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for headline event', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->HeadlineEvent->delete($id)) {
			$this->Session->setFlash(__('Headline event deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Headline event was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
