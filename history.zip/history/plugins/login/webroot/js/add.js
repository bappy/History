$j(document).ready(function(){
	
	
	if ($(window).width() > 1280)
	{
	
		document.getElementById('content').style.width = '1423'+'px';
	
	}
	
    $j(".input select#add_categories").change(function(){

    	if(this.value == 36 || this.value == 39)
    	{
    		$j("div#add_name").hide(); 
    	}
    	else
    	{
    		$j("div#add_name").show(); 
    	}

		if(this.value == 39)
    	{
    		$j(".add_year").hide(); 
    		$j(".add_year_sub").show(); 
    	}
    	else
    	{
    		$j(".add_year").show(); 
    		$j(".add_year_sub").hide(); 
    	}
    });

    $j("#LinkName").focus(function(){
      	 $j("#LinkName_autoComplete").show(); 
	});
	
	$j("#LinkName").blur(function(){
      	 $j("#LinkName_autoComplete").hide(); 
	});
	
	$j(".autocomplete li").click(function(){
		alert('live');
	});

	
	/*
	$j(".name_select").focus(function(){
	 //$j(".name_select").click(function(){
	  	id = this.id;
	  	itemID = id.match(/\d+/);
	  	
	  	value = $j("#url_" + itemID);
	  	
      	 $j("#LinkUrl").value = value; 
	});*/

});