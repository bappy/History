	var $j = jQuery.noConflict();

	$j(document).ready(function(){

    	setTimeout(function() { $j('#flashMessage').fadeOut(2000); }, 4000);
    	
  	});