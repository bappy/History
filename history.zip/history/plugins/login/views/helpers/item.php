<?php
/* /app/views/helpers/item.php */

class ItemHelper extends AppHelper {
	var $helpers = array('Html', 'ajax');

	var $prefix = null;
	var $type = "Event";
	
	function eventWithClass($event, $class) {
				
		return $this->output('
		<div id="item_list">
		'
			. $this->singleEvent($event, $class) . 
		'</div>
	
	');
	}
	
	function addSingleItem($item, $user = null, $first = null, $verbose = null) {
		
		$name = $item[$this->type]['name'];
		
		if(!empty($name))
			$name = "<b>" . $name . "</b>, ";
		
		$itemText = $name . nl2br($item[$this->type]['event']);
		$itemID = $item[$this->type]['id'];
		
		if(!$verbose)
		{
			$year = $item[$this->type]['year'];
			if($year == 0)
	 			$headerText = "Holidays";
	 		else
	 			$headerText = $year;
	 	}
	 	else
	 	{
	 		$headerText = date("F jS, Y", mktime(0, 0, 0, $item[$this->type]['month'], $item[$this->type]['day'], $item[$this->type]['year']));
	 	}
	 	
	 	if (substr($headerText, 0, 1) === '-')
	 	{
	 		$headerText = substr($headerText, 1) . " BC";
	 	}

		if($first || $verbose)
			$header = '<div class="sub_header clear">' . $headerText . '</div></br>';
		else
			$header = "";
		
		$titleLink = $this->Html->link("#" . $itemID, $this->url( array('controller' => 'events', 'action' => 'view', $itemID) ), array('class' => 'eventTitle'));

		$itemLink = '
				<div class="item_link left">	
					'. 
					$titleLink
				    . '</div>';
              
        $commentLink = "";
        
        $commentCount = $item[0]['comment_count'];
        if( $commentCount > 0)
        {
        	if($commentCount == 1)
        		$commentText = ' comment';
        	else
        		$commentText = ' comments';
        		
        	$commentLink = '
        		<div class="category left">	
					| '. 
					$this->Html->link($commentCount . $commentText, $this->url( array('controller' => 'events', 'action' => 'view', $item['Event']['id']) ), array('class' => 'eventTitle'))
       			. ' | 
       			</div>';
       }
       else
       {
      	 $commentLink = '
        		<div class="category left">	
					| '. 
					$this->Html->link("Add Comment", $this->url( array('controller' => 'events', 'action' => 'view', $item['Event']['id']) ), array('class' => 'eventTitle'))
       			. ' | 
       			</div>';
       }
       
		$editElement = "";
		$favoriteElement = "";
    	
		if( isset($user) )
		{
			$isMine = $user["id"] == $item['User']['id'];
			//Edit section
			if( $isMine || $user['admin'] )
			{
				$editElement = '
				<div class="button">
						' .
						$this->Html->link("<span class=\"edit\">Edit Event</span>", $this->url( array('controller' => 'events', 'action' => 'edit', $itemID) ), array('escape' => false ) )
						. '
				</div>';
			}
			
			//Favorites section
			$addFavorite = true;
			
			if( isset($user['Favorites']) && count($user['Favorites']) > 0)
			{
				$addFavorite = true;

				foreach($user['Favorites'] as $faveEventID)
				{
					if( $faveEventID == $itemID )
					{
						$addFavorite = false;
					}
				}
			}
			else
			{
				$addFavorite = true;
			}
	
			$removeClassText = "";
			$addClassText = "";
			
			if($addFavorite)
			{
				$addClassText = ''; 
				$removeClassText = 'hidden';  
			}
			else
			{
				$addClassText = 'hidden';
				$removeClassText = '';
			}
		
			$favoriteElement = '
			<div id="addFave_' . $itemID . '" class="button ' . $addClassText. '">
					' .
					$this->ajax->link("<span class=\"fave\">Add Favorite</span>", array('controller' => 'events', 'action' => 'addToFavorites', $itemID), array('escape' => false, 'update' => 'response_' . $itemID, 'loaded' => 'handleFavorite(\'response_' . $itemID . '\');'))
					. '
			</div>

			<div id="removeFave_' . $itemID . '" class="button ' . $removeClassText. '">
					' .
					$this->ajax->link("<span class=\"fave\">Remove Favorite</span>", array('controller' => 'events', 'action' => 'removeFromFavorites', $itemID), array('escape' => false, 'update' => 'response_' . $itemID, 'loaded' => 'handleFavorite(\'response_' . $itemID . '\');'))
					. '
				</div>
			';
		}
	
		$nameTitle = $this->getEventString($item);
		//Debugger::dump($nameTitle);
		$shareElement = '			
			<div class="button">
				<a id="shareButton_' . $itemID . '" title="Share on Facebook" onclick="'. $this->getFBJavascript($item) .'">
					<span class="fb">Facebook</span>
				</a>
			</div>
			
			<div class="button">
				<a id="shareButton_' . $itemID . '" title="Share on Twitter" onclick="tweetItem(\'' . $itemID . '\');">
					<span class="twitter">Twitter</span>
				</a>
			</div>
			
			<div class="button">
				<a id="shareButton_' . $itemID . '" title="Share through Email" onclick="emailItem(\'' . $itemID . '\', \'' . $nameTitle . '\');">
					<span class="email">Email</span>
				</a>
			</div>';

		$createdText = "";
		
		if($item['User']['admin'] == 0)
		{
			$createdText = '
						<div class="creator_name left">
							| by ' . $this->Html->link($item['User']['username'], $this->url(array('controller' => 'users', 'action' => 'view', $item['User']['id']))) . '
						</div>';
		}

		$externalLinks = "";
		if(count($item['Links']) > 0)
		{
			$externalLinks = 
				'<div class="links">
					<p>Further Reading</p>
						<ul>';
							
			foreach($item['Links'] as $link)
			{
				$externalLinks .= '<li> <a href="' . $link['url'] . '" target="_blank">' . ucfirst($link['name']) . ' </a> </li>';
			}
			$externalLinks .= 
				'</ul>
			</div>';
		}
	
		
		return 
		
		$header 
		.
		'

		<div id="item_' . $itemID . '" class="item hoverer"> 
				
				<div class="event clear">
						' . $itemText . '
				</div>
				
				<div class="item_bottom">

				 '. $itemLink . '
				 '.  $createdText . '
				 '. $commentLink . '
				 	<div class="expand left" id="expandOptions_'. $itemID . '">
				 		<a type="submit" class="expand" onclick="showItems(\''. $itemID . '\');" value=""/>+</a>
					</div>	
					<div class="expand left hidden" id="hideOptions_'. $itemID . '" >
				 		<a type="submit" class="collapse" onclick="hideItems(\''. $itemID . '\');" value=""/>-</a>
					</div>	
				</div>	
				<div class="clear"></div>
				<div class="hovered hidden clear hovered_' . $itemID . '" style="display:none;">
					<div class="top"></div>
					<div class="middle">
						'. 
						$externalLinks 
						. '
						<div class="clear"></div>
						'.
						$shareElement
						.
						$favoriteElement
						.
						$editElement
						.'	
						<div class="clear"></div>
					</div>
					<div class="bottom"></div>
					<div id="response_' . $itemID . '" class="hide"> </div>
				</div>		
				<div class="clear"></div>

		</div>';
	}
	
	function getYear($year)
	{
		if($year > 0)
		{
			return $year;
		}
		else if($year < 0)
		{
			
			return -$year . " BC";
		}
	}
	
	function getDateString($event)
	{
		return date("F jS, ", mktime(0, 0, 0, $event['month'], $event['day'], date("Y"))) . $this->getYear($event['year']);
	}
	
	function getEventString($data)
	{
		$event = $data['Event'];
		$category = $data['Category']['id'];

		if($category == 36)
	 	{
	 		return "On " . date(" F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 37)
		{
	 		return "Born on " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 38)
		{
	 		return "Dead on " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 39)
		{
	 		return "On " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day']));
	 
	 	}
	}
	
	function getFBJavascript($item)
	{
		 $id = $item[$this->type]['id'];

		$eventName = $this->getEventString($item);
		
		$categoryURL =  Configure::read('appURL') . 'events/date/'. $item[$this->type]['month'] .'/'. $item[$this->type]['day'] .'/events';
		$eventURL = Configure::read('appURL') . 'events/view/' . $id;
    
       	return "publishItem('". $id . "', '". $eventName . "','". $eventURL . "', '". $categoryURL . "');";
	}

	function addSingleUser($user, $friends = null, $User = null, $class = null) {
		
		$aboutMe = nl2br($user['about_me']);
		$userID = $user['id'];

		$name = "";
		
		if($user['name'] != '') 
		{
			$name = '
			<p>
				<span class="left"> Name: </span>
				<span class="text">&nbsp;' . $user['name'] . ' </span>
			</p>';	
		}
		
		$addLink = "";
		$removeLink = "";
						 
		if( isset($friends) && count($friends) > 0 )
		{
			$isFriend = false;
			foreach($friends as $friend)
			{
				if($friend == $userID)
				{
					$isFriend = true;
				}
			}
							
			$removeClassText = "";
			$addClassText = "";
			
			if($isFriend)
			{
				$addClassText = 'display: none;';
				$removeClassText = '';
			}
			else
			{
				$addClassText = ''; 
				$removeClassText = 'display: none;'; 
			}
			
			$addLink = $this->ajax->link('<span class=\"fave\">Add to friends</span>', array('controller' => 'users', 'action' => 'add_friend', $userID), array('title'=>'Add ' . $userID . ' to your friends', 'class' => 'add_' . $userID, 'style' => $addClassText, 'escape' => false, 'update' => 'response_' . $userID, 'loaded' => 'handleFriend(\'response_' . $userID . '\');'));
			$removeLink = $this->ajax->link('<span class=\"fave\">Remove from friends</span>', array('controller' => 'users', 'action' => 'remove_friend', $userID), array('title'=>'Remove ' . $user['username'] . ' from your friends', 'style' => $removeClassText, 'class' => 'remove_'. $userID, 'escape' => false, 'update' => 'response_' . $userID, 'loaded' => 'handleFriend(\'response_' . $userID. '\');'));
		}
		
		$submittedLink = $this->Html->link('Submitted events', $this->url(array('controller' => 'events', 'action' => 'submitted', $userID)), array('title'=>'View ' . $user['username'] . '\'s submitted events'));
		$favoriteLink = $this->Html->link('Favorite events', $this->url(array('controller' => 'events', 'action' => 'favorites', $userID)), array('title'=>'View ' . $user['username'] . '\'s favorite events'));
		$timelineLink = $this->Html->link('Private events', $this->url(array('controller' => 'events', 'action' => 'timeline', $userID)), array('title'=>'View ' . $user['username'] . '\'s private events'));

		return '
		
			<div class="user friend_' . $userID . '">

				<div class="logo">
					' . $User->getThumbnail($user) .'
				</div>
				
				<div class="data">
					<div class="header_text">
						<p>
							Username: <a title="'. $user["username"] . '\'s profile" href="'. $this->url('/users/') . $user['id'] . '">'. $user['username'] .'</a>
						</p>

						<div class="side_links">
						
						' . $addLink . '
						' . $removeLink . '
						' . $submittedLink . '
						' . $timelineLink . '
						' . $favoriteLink . '
						
						</div>
						
						' . $name . '
						
					</div>
					<div class="text clear about">
						'. $aboutMe .'
					</div>
				</div>
				
				<div id="response_'. $userID .'" style="display: none;"> </div>
			
				<div class="clear"></div>
				
			</div>';
	}
		
	function addItems($items, $user = null, $verbose = false) {
		$i = 0;
		$itemSum = "";
		
		$last = end($items);
		
		$lastYear = null;
		
		foreach ($items as $item):
		
			if($lastYear != $item[$this->type]['year'])
			{
				$first = true;
				$lastYear = $item[$this->type]['year'];
			}
			else
				$first = false;
			
			if(isset($this->params['mobile']))
				$itemSum .= $this->singleMobileEvent($event, $class, $page, $user);
			else
				$itemSum .= $this->addSingleItem($item, $user, $first, $verbose);
				
			if($last != $item)
				$itemSum .= '';
			
		endforeach;
		
		$itemSum .= '<div class="clear"></div>';
		
		return $this->output($itemSum);
	}
	
	function addValidationError($errorArray, $errorField)
	{
		if(isset($errorArray) && isset($errorArray[$errorField]))
			return $this->output( '<div class="error-message">' . $errorArray[$errorField] . '</div>' ); 
	}
	
	function addiPhoneValidationError($errorArray, $errorField)
	{
		if(isset($errorArray) && isset($errorArray[$errorField]))
			return $this->output( '<div class="error_message">' . $errorArray[$errorField] . '</div>' ); 
	}
	
	function paginatorCode($paginator, $pageAmount, $type) {
	
		return '

		<div class="paging" >
			<ul style="margin-left:0px; margin-top:0px;">
				<li>' . $this->urlSwap( $paginator->first('<<'.__('', true), null, array('class'=>'disabled')) ) . '</li>
				<li>' . $this->urlSwap( $paginator->prev('Prev'.__('', true), array(), null, array('class'=>'disabled')) ) . '</li>
				<li>' . $this->urlSwap( $paginator->numbers(array('modulus' => $pageAmount, 'seperator' => "")) ) . ' </span>
				<li>' . $this->urlSwap( $paginator->next('Next'.__('', true), array(), null, array('class'=>'disabled')) ) . '</li>
				<li>' . $this->urlSwap( $paginator->last(__('', true).'>>', array(), null, array('class'=>'disabled')) ) . ' </li>
			</ul>
		</div>
		
		<div class="paging_text">
		'. 
		$paginator->counter(array('format' => __('<b>Showing %start% to %end% </b> of %count%.', true)))
		.'
		</div>';
	}
	
	function addPaginatorPages($paginator, $type)
	{	
		if($paginator->counter(array('format' => __('%count%', true))) <= 20)
			return;
			
		if(isset($this->params['mobile']))
				return $this->output($this->paginatorCode($paginator, 2, $type));
			else	
				return $this->output($this->paginatorCode($paginator, 9, $type));
	}
	
	function addPaginator($paginator)
	{
		return $this->output($this->paginatorCode($paginator, $type));
	}
	
	function addEventAmount($paginator)
	{
		$eventAmount = $paginator->counter(array('format' => __('%count%', true)));
		if($eventAmount == 0)
			return;
		else if($eventAmount == 1)
			return $this->output(
			'<div class="right" style="margin-right:98px; margin-top:-25px;">
				1 event
			</div>');
		else
			return $this->output(
			'<div class="right" style="margin-right:98px; margin-top:-25px;">
				' . $paginator->counter(array('format' => __(' %count% events', true))) . '
			</div>');
	}
	
	function addShareThis()
	{
		return $this->output('
		<div class="share_this">
		
			<script type="text/javascript" src="http://w.sharethis.com/button/sharethis.js#publisher=ae133755-1950-4220-b35a-ac569cccaefa&amp;type=website"></script>
		
		</div>');
	}
	
	function getProperText($amount, $singleText, $severalText)
	{
		if( $amount == 0 )
			$eventText = "0 " . $severalText;
		if( $amount == 1 )
			$eventText = $amount . " " . $singleText;
		else if ( $amount > 1 )
			$eventText = $amount . " " . $severalText;
		return $eventText;
	}
	
	function addLogin()
	{
		return $this->output('
		<!-- BEGIN: Login -->

 			<div id="container">
				<a href="/users/login" class="signin">Login </a>
				<fieldset id="signin_menu">
					<form method="post" id="signin" action="/users/login">
						<label for="username">Username</label><p></p>
						<input id="username" name="data[User][username]" value="" title="username" tabindex="4" type="text">
						<p></p></br>
						<p>
							<label for="password">Password</label><p></p>
						<input id="password" name="data[User][login_password]" value="" title="password" tabindex="5" type="password">
						</p>
						<p class="remember">
							<input id="signin_submit" value="" tabindex="6" type="submit">
							<input id="remember" name="data[User][remember_me]" value="1" tabindex="7" type="checkbox">
							<label for="remember">Remember me</label>
						</p>
						<p class="forgot"> <a href="/users/reset_password" id="resend_password_link" title="You will need your email for this." >Forgot your password?</a> </p>
					</form>
				</fieldset>
			</div>
  		<!-- END: Login --> 
  		');
	}

	function getAdsenseAd()
	{
		return $this->output('
		
		<div class="adsense" >
		
		<script type="text/javascript"><!--
google_ad_client = "pub-8626477853631792";
/* Event - Top, 728x90, created 12/3/09 */
google_ad_slot = "2502253069";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
		
		</div>

		');
	}
	
	function getMobileAdsenseAd()
	{
		return $this->output('
		
		<div class="adsense" >
		
			<script type="text/javascript"><!--
window.googleAfmcRequest = {
  client: \'ca-mb-pub-8626477853631792\',
  ad_type: \'text_image\',
  output: \'html\',
  channel: \'\',
  format: \'320x50_mb\',
  oe: \'utf8\',
  color_border: \'555555\',
  color_bg: \'EEEEEE\',
  color_link: \'0000CC\',
  color_text: \'000000\',
  color_url: \'008000\',
};
//--></script>
<script type="text/javascript" 
   src="http://pagead2.googlesyndication.com/pagead/show_afmc_ads.js"></script>
		
		</div>

		');
	}
	
	function getAnalytics()
	{
		return $this->output('
		
		<!-- Woopra Code Start -->
		<script type="text/javascript" src="//static.woopra.com/js/woopra.v2.js"></script>
		<script type="text/javascript">
		woopraTracker.track();
		</script>
		<!-- Woopra Code End -->

		<script type="text/javascript">
		var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		document.write(unescape("%3Cscript src=\'" + gaJsHost + "google-analytics.com/ga.js\' type=\'text/javascript\'%3E%3C/script%3E"));
		</script>
		<script type="text/javascript">
		try {
		var pageTracker = _gat._getTracker("UA-11406005-2");
		pageTracker._trackPageview();
		} catch(err) {}</script>');
	}
	
	function url($url)
	{	
		if( isset($this->params['mobile']) )
		{
			if( is_array( $url ) )
			{
				$url['mobile'] = true;
				//$url[$this->prefix] = true;
			}
			else
			{
				$url = '/mobile' . $url;
			}
		}
		else if( isset($this->params['iphone']) )
		{
			if( is_array( $url ) )
			{
				$url['iphone'] = true;
			}
			else
			{
				$url = '/iphone' . $url;
			}
		}
		
		return $url;
	}
	
	function getPrefix()
	{
		if( isset($this->params['mobile']) )
			return "mobile/";
		else if( isset($this->params['iphone']) )
			return "iphone/";
		else
			return "";
		
	}
	
	function urlSwap($url, $exchangeText = null)
	{
		if( isset($this->params['mobile']) )
		{
			if( !isset($exchangeText) )
				return str_replace("href=\"", "href=\"/mobile", $url);	
			else
				return str_replace($exchangeText . "=\"", $exchangeText  ."=\"/mobile", $url);	
		}
		else if( isset($this->params['iphone']) )
		{
			if( !isset($exchangeText) )
				return str_replace("href=\"", "href=\"/iphone", $url);	
			else
				return str_replace($exchangeText . "=\"", $exchangeText  ."=\"/iphone", $url);	
		}
		else
			return $url;
	}
	
	function getButton($text, $options = "", $class = "", $style = "")
	{
		return $this->output('
		<div class="rounded_button '. $class . '" style="' . $style . '">
			<table cellspacing="0" cellpadding="0" border="0">

					<tr class="top_row">
						<td class="tl"/>
						<td class="content" rowspan="2">
							<div class="bottom clearfix">
								<a ' . $options . ' style="font-size: 11px; background-color: transparent; color: rgb(51, 51, 51);">' . $text . '</a>
							</div>
						</td>
						<td class="tr"/>
					</tr>
					<tr class="lower_row">
						<td class="bl"/>
						<td class="br"/>
					</tr>
		
			</table>
		</div>');
	}
	
	function addiPhoneItems($items) {
		$i = 0;
		$sum = "";
		
		$lastItem = end($items);
		
		foreach ($items as $item):
		
			$class = 'main_row';
			if ($i++ % 2 == 0) {
				$class = 'alt_row';
			}
			
			$sum .= $this->singleiPhoneItem($item);
			
			if($lastItem != $item)
				$sum .= '';
			
		endforeach;
		
		$sum .= '<div class="clear"></div>';
		
		return $this->output($sum);
	}
	
	function singleiPhoneItem($item) {

		if(empty($item['Event']['title']))
			$itemName = "Event " . $item['Event']['id'];
		else
			
			$itemName = $item['Event']['title'];

		$itemText = nl2br($item['Event']['event']);
		$itemID = $item['Event']['id'];
		
		$rating = intval($item['Event']['rating']);

        $reviewText = $this->getProperText($item['Event']['votes'], "Review", "Reviews");

		return '
		
		<li class="item">
			<a class="noeffect" href="/iphone/events/edit/' . $itemID . '">
			<span class="title">
				' . $itemName . '
			</span>
			<span class="category">
				' . $item['Category']['name'] . '
			</span>
			<span class="text">
				' . $itemText . '
			</span>
			<img alt="rating" class="stars" src="/img/iphone/' . $rating . 'stars.png" />
			<span class="starcomment"> '. $reviewText . '</span>
			<span class="arrow"></span>
			</a>
		</li>';
		
		//$this->element('rating', $rating) 
	}
	
	function singleAppItem($appArray)
	{

		return $this->output( '
		<li class="withimage '. $appArray['cellClass'].'">
			<a class="noeffect '. $appArray['class'] .'" href="'. $appArray['link'] . '">
				<span class="name">'. $appArray['name'] . '</span>
				<span class="comment">'. $appArray['info'] . '</span>
				<span class="category">'. $appArray['category'] . '</span>
				<span class="price">'. $appArray['price'] . '</span>
				<span class="arrow"/>
				
			</a>
		</li>');
	
	}
}

?>
