<?php
   class XMLHelper extends AppHelper
   {
   
   		function header($attrib = array()) 
   		{
   			if (Configure::read('App.encoding') !== null) {
				$this->encoding = Configure::read('App.encoding');
			}
	 
			if (is_array($attrib)) {
				$attrib = array_merge(array('encoding' => $this->encoding), $attrib);
			}
			
			if (is_string($attrib) && strpos($attrib, 'xml') !== 0) {
				$attrib = 'xml ' . $attrib;
			}
	
			return $this->output($this->Xml->header($attrib));
		}
   }
?> 