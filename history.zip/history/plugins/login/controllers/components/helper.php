<?php

class HelperComponent extends Object
{
	var $controller;
    var $isFacebook = null;
    var $isMobile = null;
    
    function initialize()
    {
    }
   
    function url($url)
	{			
		//Debugger::dump($this);
		
		if( $this->isFacebook )
		{
			if( is_array( $url ) )
			{
				$url['facebook'] = true;
				//$url[$this->prefix] = true;
			}
			else
			{
				$url = '/facebook' . $url;
			}
		}
			
		if( $this->isMobile )
		{
			if( is_array( $url ) )
			{
				$url['mobile'] = true;
				//$url[$this->prefix] = true;
			}
			else
			{
				$url = '/mobile' . $url;
			}
		}
			
		return $url;
	}
	
	function getPrefix()
	{
		if( isset($this->params['facebook']) )
			return "facebook/";
		else
			return "";
		
	}
	
	function urlSwap($url, $exchangeText = null)
	{
		if( isset($this->params['facebook']) )
		{
			if( !isset($exchangeText) )
				return str_replace("href=\"", "href=\"/facebook", $url);	
			else
				return str_replace($exchangeText . "=\"", $exchangeText  ."=\"/facebook", $url);	
		}
		else
			return $url;
	}
    
}
?>