<?php

class ContactsController extends AppController {

	var $name = 'Contacts';
	var $helpers = array('Html', 'Form', 'Crumb');
	var $components = array('RequestHandler', 'Email');
	
	function index() {
	
		$this->set('name', "");
        $this->set('subject', "");
       	$this->set('email', "");
		$this->set('details', "");
        $this->set('nameError', "");
        $this->set('emailError', "");
        $this->set('detailsError', "");
        $this->pageTitle = 'Contact Us';
        
    	if (!empty($this->data)) {
			if ($this->RequestHandler->isPost()) {
           			
				$this->Contact->set($this->data);
				if ($this->Contact->validates()) {
        	   		//send email using the Email component
            		$this->Email->to = 'support@downshiftit.com';  
            		$this->Email->sendAs = 'both';
        	    	$this->Email->subject = 'iJoke - ' . $this->data['Contact']['subject'];  
          	  		$this->Email->from = $this->data['Contact']['email'];  
         	   		$this->Email->send($this->data['Contact']['name'] . ' says : ' . $this->data['Contact']['details']);
         	   		
         	   		$this->Session->setFlash(__('Email has been sent.', true), 'default', array('class' => 'success'));
            	} else {
            	
            		$errors = $this->Contact->invalidFields();
            		
            		$this->set('name', $this->data['Contact']['name']);
            		$this->set('subject', $this->data['Contact']['subject']);
            		$this->set('email', $this->data['Contact']['email']);
           			$this->set('details', $this->data['Contact']['details']);
           			
            						
            		if(!empty($errors['name'])) 
						$this->set('nameError', $errors['name']); 
					
					if(!empty($errors['email'])) 
						$this->set('emailError', $errors['email']);
					
					if(!empty($errors['details']))  
						$this->set('detailsError', $errors['details']);
					
					$this->Session->setFlash(__('Email could not be sent. Make sure you have filled out all of the information.', true));
				}
			}
		}
		else
		{
			if( $this->isLoggedIn() )
			{
				$currentUser = $this->loggedUser();
				
				if(array_key_exists('name', $currentUser))
				{
					$this->set('name', $currentUser['name']);
				}
				
				if(array_key_exists('email', $currentUser))
				{
       				$this->set('email',  $currentUser['email']);
				}
			}
			
			$this->set('subject', "Concerning " . Configure::read('appName'));
		}
    
    }
}

?>