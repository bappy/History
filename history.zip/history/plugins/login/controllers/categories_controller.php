<?php

class CategoriesController extends AppController {

	var $name = 'Categories';
	var $helpers = array('Html', 'Form');

	function beforeFilter()
    {
    	parent::beforeFilter();
	 	$this->Auth->allow('*');
	}
	
	function index() {
		$this->Category->recursive = 0;
		$this->set('categories', $this->paginate());
	}
}
?>