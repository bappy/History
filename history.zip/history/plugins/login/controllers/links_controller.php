<?php
class LinksController extends AppController {

	var $name = 'Links';
	var $helpers = array('Html', 'Form', 'Ajax', 'Time', 'Complete');
	var $components = array('RequestHandler');

	function index($id = 0) {
		
		$links = $this->Session->read('links');  
		
		$this->set('links', $links);
		$this->set('User', $this->User);
		
		$this->set('_foreignKey', $id);
	}

	function add() {
	
		if (!empty($this->data))
		{
			$this->Link->set($this->data);

			if($this->Link->validates())
			{
				$links = $this->Session->read('links');  
				$links[] = $this->data;
				$this->set('links', $links);
				
				$this->Session->write('links', $links);
				$this->Session->setFlash(__('Link Added', 'default', array('class' => 'success')));
				$this->redirect( $this->Session->read('link_url') );
			}
			
		}
		else
		{
			$this->data['Link']['url'] = "http://www.";
		}
		
	}

	function delete($id = null) {
		
		$links = $this->Session->read('links');  
		$current = 0;
		$newLinks = array();
		
		foreach ($links as $link){
		
			if ($current != $id)
			{
				$newLinks[] = $link;
			}
			$current++;
		}
		
		$this->Session->write('links', $newLinks);
		$this->set('links', $newLinks );
		
		$this->Session->setFlash(__('Link deleted', 'default', array('class' => 'success')));
		
		$this->redirect( $this->Session->read('link_url') );
	}
	
	//======================================================================
	//Service Functions
	//======================================================================
	
	function service_addWiki() {
	
		$this->setupJSON();

		/**/
		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		
		$url = $jsonData["url"];
		
		if(array_key_exists('name', $jsonData))
			$name = $jsonData["name"];
		else
			$name = null;
		
		$name = str_replace("/wiki/", "", $name);
		$pos = strpos($name, "?");
		if($pos === false)
		{
			$url = "http://en.wikipedia.org/wiki/" . $name ;
			$name = str_replace("_", " ", $name);
		}
		else
		{
			$url = "http://en.wikipedia.org/wiki/" . $name ;
			$name = str_replace("_", " ", $name);
		}
			
		//$url = "http://en.wikipedia.org/wiki/Ettore_Sottsass";
		//$name = "Ettore_Sottsassa";
		
		$saved = $this->Link->alreadySaved($url);
		if($saved)
		{
			$results['Results'] = "Success";
			$results['Link'] = $saved;
		}
		else
		{		
			$data = array(
					'Link' => array(
						'url' => $url,
						'name' => $name
					)			
			);
			
			//Debugger::dump($data['Link']);
			
			$this->Link->set($data);
			//if($this->Link->validates())
			$saveResult = $this->Link->save($data);
			if($saveResult)
			{
				//$data['Link']['id'] = 999;
				$data['Link']['id'] = $this->Link->id;
				$results['Results'] = "Success";
				$results['Link'] = $data['Link'];
			}
			else
			{
				$results['Results'] = "Fail";
			}
		
		}
		//Debugger::dump($results);
		
		$this->set('results', $results);
	}
	
	function service_add() {
	
		$this->setupJSON();

		/**/
		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		
		$url = $jsonData["url"];
		//$url = substr($url, 0, strpos($url, "?"));
		
		//Debugger::dump($jsonData);
		if(array_key_exists('name', $jsonData))
			$name = $jsonData["name"];
		else
			$name = null;
		
		//$url = "http://www.pacoequip.com/";
		//$name = "Pacific American Commercial Company, PACO, paco";
		
		$saved = $this->Link->alreadySaved($url);
		if($saved)
		{
			$results['Results'] = "Success";
			$results['Link'] = $saved;
		}
		else
		{		
			$data = array(
					'Link' => array(
						'url' => $url,
						'name' => $name
					)			
			);
			
			//Debugger::dump($data['Link']);
			
			$this->Link->set($data);
			//if($this->Link->validates())
			$saveResult = $this->Link->save($data);
			if($saveResult)
			{
				//$data['Link']['id'] = 999;
				$data['Link']['id'] = $this->Link->id;
				$results['Results'] = "Success";
				$results['Link'] = $data['Link'];
			}
			else
			{
				$results['Results'] = "Fail";
				$results['name'] = $name;
				$results['url'] = $url;
			}
		}

		
		$this->set('results', $results);
	}


    function edit($id = null) {


        if (!$id && empty($this->data)) {
            $this->Session->setFlash(__('Invalid event', true));
            $this->redirect(array('action' => 'index'));
        }
        if (!empty($this->data)) {
            if ($this->Event->save($this->data)) {
                $this->Session->setFlash(__('The event has been saved', true));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The event could not be saved. Please, try again.', true));
            }
        }
        if (empty($this->data)) {
            $this->data = $this->Event->read(null, $id);

        }
	
}

}
?>