<?php

class ErrorsController extends AppController {

	var $name = 'Errors';
	
}