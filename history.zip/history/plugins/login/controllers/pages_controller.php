<?php

/**
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @filesource
 * @copyright     Copyright 2005-2008, Cake Software Foundation, Inc. (http://www.cakefoundation.org)
 * @link          http://www.cakefoundation.org/projects/info/cakephp CakePHP(tm) Project
 * @package       cake
 * @subpackage    cake.cake.libs.controller
 * @since         CakePHP(tm) v 0.2.9
 * @version       $Revision$
 * @modifiedby    $LastChangedBy$
 * @lastmodified  $Date$
 * @license       http://www.opensource.org/licenses/mit-license.php The MIT License
 */

App::import('Sanitize');


class PagesController extends AppController {

/**
 * Controller name
 */
	var $name = 'Pages';
	var $helpers = array('Html', 'Item');
	var $uses = array('Joke');

	function beforeFilter()
	{
		parent::beforeFilter();
		
		$this->setDescriptions( $this->action);
		$this->setTitle( $this->action);
		$this->setViewPath( $this->action );
	}
	
	
/**
 * Displays a view
 *
 * @param mixed What page to display
 * @access public
 */
	
	function display() {
		
		$path = func_get_args();

		$count = count($path);
		if (!$count) {
			$this->redirect('/');
		}
		
		if(array_key_exists('layout', $this->passedArgs) )
		{
			$this->layout = $this->passedArgs['layout'];
			
			/*
			switch ($this->passedArgs['layout']) {

				$this->layout = 'popup';
				break;
			default:
				$layout = 'default';
				break;
			}*/
		}
			
		$page = $subpage = $title = null;

		if (!empty($path[0])) 
		{
			$page = $path[0];
			
			if ($page == 'home') 
			{
            	//$this->home();
       		}
       
		}
		if (!empty($path[1])) {
			$subpage = $path[1];
		}
		if (!empty($path[$count - 1])) {
			$title = Inflector::humanize($path[$count - 1]);
		}
		$this->set(compact('page', 'subpage', 'title'));
		$this->render(join('/', $path),$this->layout);
	}
	
	function tab() {}
	
	function terms_of_service() {}
	
	function privacy_policy() {}
	
	function home() 
	{
		
		if( $this->MobileDetection->IsMobile() && !$this->isLayoutType('mobile') )
		{
			if( !isset($this->params['url']['nm']))
				$this->redirect('/mobile');	
		}
		
		$model = ClassRegistry::init('Joke', 'Model');
		$model->recursive = 0;
		$model->current = "latest";
		$this->paginate = $model->getLatest();
		$this->set('items', $this->paginate());
		//$this->paginate = $this->Joke->getLatest();
		//$this->set('latest', $latest);
		
	}
	
	//======================================================================
	//iPhone Pages
	//======================================================================
	
	function iphone_terms_of_service() 
	{
		if( isset($this->params['url']['hide']) )
			$this->set('show', false);
		else
			$this->set('show', true);
	}
	
	function iphone_privacy_policy()
	{ 
		if( isset($this->params['url']['hide']) )
			$this->set('show', false);
		else
			$this->set('show', true);
	}
	
	function iphone_faq()
	{ 
	}
	
	function iphone_other_apps()
	{ 
	}

	//======================================================================
	// Helpers
	//======================================================================
	
	function setDescriptions($action)
	{
		switch ($action) {
			default:
				$meta_description = "www.todayhistory.net is dedicated to sharing world history and personally significant \"historical\" information. Sign up now so you can share the fun of what happened today or any day for that matter";
				$meta_keywords = "happened today in history, events today in history, births today in history, what happend today in history, famous people history, events history, timelines, personal timelines, this day in history, history today";
				break;
		}
		
		$this->set('meta_description', $meta_description);
		$this->set('meta_keywords', $meta_keywords);
	}
	
	function setTitle($action)
	{
		switch ($action) {
			case "faq":
				$pageTitle = "Frequently Asked Questions";
				break;
			case "iphone_faq":
				$pageTitle = "FAQs";
				break;
			case "iphone_terms_of_service":
				$pageTitle = "Terms of Service";
				break;
			case "iphone_privacy_policy":
				$pageTitle = "Privacy Policy";
				break;
			case "iphone_other_apps":
				$pageTitle = "Down-Shift's Apps";
				break;
			default:
				$pageTitle = "";
				break;
		}
		
		$this->pageTitle = $pageTitle;
	}
	
	function setViewPath($action)
	{
		if( $this->layout == "iphone")
			$this->viewPath = $this->viewPath . DS . 'iphone';
	}
	
		//======================================================================
	//iPhone Pages
	//======================================================================
}

?>