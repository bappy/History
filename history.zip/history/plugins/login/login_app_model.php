<?php 

class LoginAppModel extends AppModel {

 	var $current;


    function find($conditions = null, $fields = array(), $order = null, $recursive = null) {
  
		$doQuery = true;
   
       	//Check if we want the cache
        if (!empty($fields['cache'])) {
   
        	$cacheConfig = null;
   
        	// check if we have specified a custom config, e.g. different expiry time
       	 	if (!empty($fields['cacheConfig']))
            	$cacheConfig = $fields['cacheConfig'];
 
 	
        	$cacheName = $this->name . '_' . $fields['cache'];
        	
        	//Debugger::dump($cacheName  );
            // if so, check if the cache exists
            if (($data = Cache::read($cacheName, $cacheConfig)) === false) {
            	$data = parent::find($conditions, $fields, $order, $recursive);
             	Cache::write($cacheName, $data, $cacheConfig);
            }
  
            return $data;
        }

        $data = parent::find($conditions, $fields, $order, $recursive);
       	return $data;
	}
	
	function validates($options = array()) {
    // copy the data over from a custom var, otherwise
    $actionSet = 'validate' . Inflector::camelize(Router::getParam('action'));
    if (isset($this->validationSet)) {
        $temp = $this->validate;
        $param = 'validate' . $this->validationSet;
        $this->validate = $this->{$param};
    } elseif (isset($this->{$actionSet})) {
        $temp = $this->validate;
        $param = $actionSet;
        $this->validate = $this->{$param};
    } 
    
    $errors = $this->invalidFields($options);

    // copy it back
    if (isset($temp)) {
        $this->validate = $temp;
        unset($this->validationSet);
    }
    
    if (is_array($errors)) {
        return count($errors) === 0;
    }
    return $errors;
}
/*
	function paginate($conditions, $fields, $order, $limit, $page = 1, $recursive = null, $joins = null) {

		Debugger::dump($joins['joins']);
		
		if($this->current == "no-cache")
		{
			$params = array(
		  		'conditions' => $conditions,
		  		'recursive' => $recursive,
		  		'fields' => $fields,
		 		 'order' => $order,
		 		 $joins,
		  		'limit' => $limit,
		  		'page' => $page
	 		);
		}
		else
		{
			$params = array(
		  		'conditions' => $conditions,
		  		'recursive' => $recursive,
		  		'fields' => $fields,
		 		 'order' => $order,
		 		 $joins,
		  		'limit' => $limit,
		  		'cache' => $this->current . '_' . $page,
		  		'cacheConfig' => 'medium',
		  		'page' => $page
	 		);
		}

	 	return $this->find('all', $params);
	}
	*/
	
	function paginationCount($params = null) {
	
		if(array_key_exists('order', $params))
			unset($params['order']);
			
		if(array_key_exists('fields', $params))
			unset($params['fields']);
	
	 	return $this->find('count', $params);
	}
}

?>