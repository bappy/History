<?php
class Comment extends AppModel {

	var $name = 'Comment';
    var $useTable=false;
	var $validate = array(
		'comment' => array(
			'between' => array(
				'rule' => array('between', 5, 400),
				'required' => true,
				'message' => 'Must be between 5 to 400 characters'
			)
		),
		'model' => array('notempty'),
		'foreign_key' => array('numeric'),
		'creator_id' => array('numeric')
	);

	var $fields = array('Comment.id', 'Comment.comment', 'Comment.created',
    		'User.id', 'User.username', 'User.fbid');
	
	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
			'User' => array('className' => 'User',
								'foreignKey' => 'creator_id',
								'conditions' => '',
								'fields' => '',
								'order' => ''
			)
	);
	
	function getByID($id) {
		$this->recursive = 0;
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Comment.id' => $id)
		);

		return $this->find('first', $params);
	}
}
?>
