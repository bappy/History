<?php
class LoginCategoryModel extends LoginAppModel {
	var $name = 'Category';
	var $displayField = 'name';
	//The Associations below have been created with all possible keys, those that are not needed can be removed
	
	var $belongsTo = array(
		'Application' => array(
			'className' => 'Application',
			'foreignKey' => 'application_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
	
	function getCategories() {
		$this->recursive = -1;
		$params = array(
			'conditions' => array('Category.application_id' => 3),
			'order' => array('Category.id ASC'),
			'cache' => 'categoryList',
			'cacheConfig' => 'long'
		);

		return $this->find('all', $params);
	}
	
	function getCategoriesBasic() {
		$this->recursive = -1;
		$params = array(
			'fields' => array('Category.id', 'Category.name'),
			'conditions' => array('application_id' => 3),
			'order' => array('Category.id ASC'),
			'cache' => 'basicCategoryList',
			'cacheConfig' => 'long'
		);

		return $this->find('list', $params);
	}
	
	function getIDForName($name) {
	
		switch (ucfirst($name)):
    		case 'Events':
        		return 36;
   	 		case 'Births':
        		return 37;
    		case 'Deaths':
        		return 38;
        	case 'Holidays':
        		return 39;
    		default:
        		return 36;
		endswitch;

	}
	
	function getNameForID($id) {
	
		switch ($id):
    		case 36:
        		return 'Event';
   	 		case 37:
        		return 'Birth';
    		case 38:
        		return 'Death';
        	case 39:
        		return 'Holidays';
    		default:
        		return 'Event';
		endswitch;
	}
	
	function GetMonthString($n)
	{
    	$timestamp = mktime(0, 0, 0, $n, 1, 2005);
    	return date("F", $timestamp);
	}
	
}
?>