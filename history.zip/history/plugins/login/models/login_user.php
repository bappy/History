<?php
class LoginUser extends LoginAppModel
{	
	var $name = 'LoginUser';
    var $useTable = 'users';
    var $components = array('Auth');
	var $userName = null;
	var $userEmail = null;

	var $hasMany = array(
        'Events' => array(
            'className'     => 'Event',
            'foreignKey'    => 'user_id',
            'order'    => 'Events.id DESC',
            'dependent'=> false
        	), 
   		'Comments' => array(
            'className'     => 'Comment',
            'conditions'   => array('model' => 'events'),
            'foreignKey'    => 'creator_id',
            'order'    => 'Comments.id DESC',
            'dependent'=> false
        )
	); 
   		
	var $hasAndBelongsToMany = array(
		'Friend' => array(
			'className'     => 'User',
            'joinTable' => 'users_friends',
			'foreignKey' => 'user_id',
			'associationForeignKey' => 'friend_id',
			'unique' => true
        ), 
   		'Favorites' => array(
            'className' => 'Event',
            'joinTable' => 'events_users',
			'foreignKey' => 'user_id',
			'associationForeignKey' => 'event_id',
			'unique' => true
        )
    );

	var $fields = array('User.id, User.name, User.created, User.fbid, User.iphone_id, User.email, User.about_me, User.birthdate, User.url, User.username, User.admin, User.gender');
   
    var $validate = array(
		'id' => array(
			'rule' => 'blank',
			'on' => 'create'),
		'username' => array(
			'isUnique' =>  array(
				'rule' => 'isUnique',
				'message' => 'This username has already been taken.',
				'on' => 'create'
			),
			'isUniqueUpdate' =>  array(
				'rule' => array('uniqueField', 'username'),
				'message' => 'This username has already been taken.',
				'on' => 'update'
			),
			'between' => array(
				'rule' => array('between', 5, 40),
				'required' => true,
				'message' => 'Must be between 5 to 40 characters'
			),
			'custom' => array(
				'rule' => array('custom', '/^[A-Za-z0-9_ ]*$/i'),
				'message' => 'Usernames can only contain letters, numbers, and _'
			)
		),
		'name' => array(
			'between' => array(
				'rule' => array('between', 0, 80),
				'message' => 'Must be less than 80 characters'
			),
			'custom' => array(
				'rule' => array('custom', '/^[A-Za-z. ]*$/i'),
				'message' => 'Name can only contain letters,  spaces, and .\'s'
			)
		),
		'email' => array(
			'isUnique' =>  array(
				'rule' => 'isUnique',
				'message' => 'This email has already been taken.',
				'on' => 'create'
			),
			'isUniqueUpdate' =>  array(
				'rule' => array('uniqueField', 'email'),
				'message' => 'This email has already been taken.',
				'on' => 'update'
			),
			'email' => array(
				'rule' => 'email',
				'required' => true,
				'message' => 'Must be a valid email adress'
			),
			'maxLength' => array(
				'rule' => array('maxLength', 250),
				'message' => 'Email should be shorter.'
			),
			'minLength' => array(
				'rule' => array('minLength', 5),
				'message' => 'Email should be longer.'
			)
		),
		/*'password' => array(
				'rule' => array('confirmPassword'),
				'message' =>  'Passwords do not match',

		),
		*/
		'password_confirm' => array(
			'between' => array(
				'rule' => array('between', 5, 25),
				'message' => 'Field must be between 5 to 25 characters'
			)
		)
	);
		
	var $validateEdit = array(
	
		'username' => array(
			'isUnique' =>  array(
				'rule' => 'isUnique',
				'message' => 'This username has already been taken.',
			),
			'between' => array(
				'rule' => array('between', 5, 40),
				'required' => true,
				'message' => 'Must be between 5 to 40 characters'
			),
			'custom' => array(
				'rule' => array('custom', '/^[A-Za-z0-9_ ]*$/i'),
				'message' => 'Usernames can only contain letters, numbers, and _'
			)
		),
		'about_me' => array(
			'between' => array(
				'rule' => array('between', 0, 250),
				'message' => 'Must be shorter than 250 characters'
			)
		),
		'name' => array(
			'between' => array(
				'rule' => array('between', 0, 80),
				'message' => 'Must be less than 80 characters'
			),
			'custom' => array(
				'rule' => array('custom', '/^[A-Za-z ]*$/i'),
				'message' => 'Name can only contain letters and spaces'
			)
		),
		'birthdate' => array(
			'date' => array(
				'rule' => 'date',
				'message' => 'This date is not valid.'
			),
			'notEmpty' => array(
				'rule' => 'notEmpty',
				'required' => false,
				'allowEmpty' => false
			)
		),
		'email' => array(
			'isUnique' =>  array(
					'rule' => 'isUnique',
					'message' => 'This email has already been taken.',
					'on' => 'create'
					),
			'email' => array(
				'rule' => 'email',
				'required' => true,
				'message' => 'Must be a valid email adress'
			),
			'between' => array(
				'rule' => array('between', 5, 40),
				'message' => 'Must be between 5 to 40 characters'
			)
		),
		'url' => array(
				'rule' => array('url', true),
				'message' => 'Must be a valid url, ie. www.downshiftit.com'
		)
	);

	var $validateFB = array(
		'username' => array(
			'isUnique' =>  array(
				'rule' => 'isUnique',
				'message' => 'This username has already been taken.',
			),
			'required' => array(
				'rule' => 'required'
			)
		)
	);
	
	function confirmPassword($data) {
		$valid = false;
        echo debug($data);
		if ($data['password'] == Security::hash(Configure::read('Security.salt') . $this->data['LoginUsers']['password_confirm'])) {
			$valid = true;
		}
		return $valid;
	}
		
	function uniqueField($data){
		
		$field = key($data);
		$userName = $this->find(array($field => $data[$field]));
			
		if(!$userName)
			return true;
			
		if($field == 'username')
			$fieldValue = $this->userName;
		else if($field == 'email')
			$fieldValue = $this->userEmail;
			
		if($fieldValue == $userName['User'][$field])
		{
			return true;
		}
		else
		{		
			return false;
		}
	}
	
	function changeURL($url)
	{
      	if (preg_match("#^http://www#i", $url))
      		return $url;
      	else if(preg_match("#^www#i", $url))
      		return 'http://' . $url;
      	else
      	{
      		$testURL = 'http://www.' . $url;
      		if (preg_match("#^http://www\.[a-z0-9-_.]+\.[a-z]{2,4}$#i",$testURL))
      			return $testURL;
      	}
      	
      	return $url;
	}
	
	function getByID($id, $recursive = 0) {
		$this->recursive = $recursive;
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('User.id' => $id),
			//'cache' => 'user_' . $id,
			//'cacheConfig' => 'short'
		);

		return $this->find('first', $params);
	}
	
	function getByFBID($fb_id)
	{
		$this->recursive = -1;
	 	return $this->find('first',
	 		array(
            	'conditions' => array('fbid' => $fb_id),
            	'fields' => $this->fields,
            ));           
	}
 
 	function getDuplications()
 	{
 		$results = $this->query("SELECT event_id, link_id,count(link_id)
			FROM events_links
			GROUP BY event_id, link_id
			HAVING COUNT(link_id) >1");
		
		foreach($results as $result){
			//$this->query('DELETE FROM `downshif_web`.`events_links` WHERE `events_links`.`link_id` = '. $result['events_links']['link_id']. ' AND `events_links`.`event_id` = '. $result['events_links']['event_id']. ' LIMIT 1');
		}
	}
	
 	function getLatest() {
		return array(
			'fields' => 'User.id',
			'conditions' => array('User.admin != 1'),
			'order' => array('User.id' => 'desc'),
			'limit' => 20
			);
	}
	
	function getFriendsPaginate($userID = null) {
		return array(
			'fields' => array('Friends.friend_id'),
			'conditions' => array('Friends.user_id' => $userID),
			'joins' => array(
				array(
					'table' => 'users_friends', 					
					'type' => 'INNER',
					'alias' => 'Friends',
					'conditions' => array(
						'User.id = Friends.user_id'
					)
				)
			),
			'limit' => 20
		);
	}
	
	function getMostActive($page) {
		return array(
			'fields' => array('User.id'),
			'group' => array('User.id'),
			'order' => 'COUNT(Events.user_id) DESC',
			'conditions' => array('User.admin != 1'),
			'joins' => array(
				array(
					'table' => 'events', 					
					'type' => 'LEFT',
					'alias' => 'Events',
					'conditions' => array(
						'User.id = Events.user_id'
					)
				)
			),
			'page' => $page,
			'limit' => 20
			);
	}
	

	function getFriends($userID = null) {	
		$this->recursive = -1;
		$results =  $this->query("
			SELECT users_friends.friend_id  from users_friends
			WHERE users_friends.user_id = " . $userID);
		
		$friends = array();
		foreach($results as $joke)
		{
			$friends[] = $joke['users_friends']['friend_id'];
		}
		return $friends;
	}
	
	function setupFBFriends($userID, $fb_friends = null) {
		
		$friends = $this->getFriends($userID);
		
		foreach($fb_friends as $friend){
			if (!in_array($friend, $friends)) {
				$this->addToFriends($userID, $friend);
			}
		}
	}
	
	function addToFriends($userID = null, $friendID = null) {	
		$friends =  $this->query("
			SELECT *  from users_friends WHERE users_friends.friend_id = " .  $friendID . " and users_friends.user_id = " . $userID);
			
		if( count( $friends ) != 0)
			return false;
			
		$this->query("
			INSERT INTO users_friends (users_friends.friend_id, users_friends.user_id) VALUES ( '" .  $friendID . "', '". $userID ."')"
		);
			
		return true;
	}
        
    function removeFromFriends($userID = null, $friendID = null) {	
		
		$friends =  $this->query("
			SELECT *  from users_friends WHERE users_friends.friend_id = " .  $friendID . " and users_friends.user_id = " . $userID);
			
		if( count( $friends ) == 0)
			return false;
			
		$this->query("
			DELETE FROM users_friends  WHERE users_friends.friend_id = " .  $friendID . " and users_friends.user_id = " . $userID);

			
		return true;
	}
	function getFriendsCount($userID = null) {
		$this->recursive = -1;
		$amount = $this->query("SELECT  COUNT(*) as amount from users_friends WHERE users_friends.user_id = " . $userID);
		return $amount[0][0]['amount'];
	}
		
	function getFaveCount($userID = null) {
			
		$this->recursive = -1;
		$amount = $this->query("SELECT  COUNT(*) as amount from events_users WHERE events_users.user_id = " . $userID);
		return $amount[0][0]['amount'];
	}
	
	function getNotifications($userID = null) {	
		return $this->getLinkedValues($userID, "notifications_users", "notification_id");
	}
	
	function addNotification($userID = null, $notificationID = null) {	
		return $this->addLinkedValues($userID, $notificationID, "notifications_users", "notification_id");
	}
        
    function removeNotification($userID = null, $notificationID = null) {	
    	return $this->removeLinkedValues($userID, $notificationID, "notifications_users", "notification_id");
	}
	
	function getLinkedValues($user_id, $link_table, $linked_key, $user_key = "user_id")
	{
		$this->recursive = -1;
		
		$results =  $this->query("
			SELECT $link_table.$linked_key from $link_table 
			WHERE $link_table.$user_key = $user_id");
			
		$values = array();
		foreach($results as $value)
		{
			$values[] = $value[$link_table][$linked_key];
		}
		return $values;
	}
	
	function addLinkedValues($user_id, $link_id, $link_table, $linked_key, $user_key = "user_id")
	{
		$exists =  $this->query("SELECT * from $link_table WHERE $link_table.$linked_key = $link_id and $link_table.$user_key = $user_id");
			
		if( count( $exists ) != 0)
			return false;
			
		$this->query("INSERT INTO $link_table ($link_table.$linked_key, $link_table.$user_key) VALUES ( '$link_id', '$user_id')");
		return true;
	}

	function removeLinkedValues($user_id, $link_id, $link_table, $linked_key, $user_key = "user_id")
	{
		$exists =  $this->query("SELECT * from $link_table WHERE $link_table.$linked_key = $link_id and $link_table.$user_key = $user_id");
			
		if( count( $exists ) == 0)
			return false;
	
		$this->query("DELETE FROM $link_table WHERE $link_table.$linked_key = $link_id and $link_table.$user_key = $user_id");
		return true;
	}

   	function validateLogin($data)
    {

    	if( strchr($data['username'],"@")  )
    		$user = $this->find(array('email' => $data['username'], 'password' => Security::hash( Configure::read('Security.salt') . $data['login_password'] )), array('id', 'username', 'fbid'));
    	else
    		$user = $this->find(array('username' => $data['username'], 'password' => Security::hash( Configure::read('Security.salt') . $data['login_password'] )), array('id', 'username', 'fbid'));

        if(!empty($user))
            return $user['LoginUser'];
        return false;
   	}
   		
   	function shouldUpdateUser($updatedUser, $user, $fields)
   	{
   		$updatedFields = array();
    	foreach($fields as $field)
   		{		
   			if($user[$field] == "" ||  $user[$field] ==	"0")
   			{
   				if($updatedUser[$field] != "")
   					$updatedFields[] = $field;
   			}
   		}
   		return $updatedFields;
   	}
   		
   	function changeDate($date)
   	{
   		if($date != "")
   			return date( 'Y-m-d', strtotime($date));
   		else
   			return "";
   	}
   		
   	function isAdmin($data)
    {
        $user = $this->find(array('username' => $data['username'], 'password' => md5($data['password'])), array('id', 'username'));
       	if(empty($user) == false)
        {
        	if(!empty($data['admin']))
           		return true;
           	else 
           		return false;
        }
       	return false;
   	}
   		
   	function getProfileURLOnly($user, $facebookURLs, $thumb = false, $root = false)
   	{
   		$url = $this->getProfileURL($user['id'], $thumb, $root);
   			
   		if( file_exists( '/home/downshif/public_html/services/webroot/images/' . $url) )
   		{
   			return 'http://profileimages.lg1x1z.simplecdn.net/' . $url;
   		}
   		else if( $user['fbid'] != 0)
   		{
   			if(!is_array($facebookURLs))
   				return;
   			
   			if($thumb)
   				return $facebookURLs['pic_square'];
   			else
   				return $facebookURLs['pic_big'];
   		}
   		else
   		{
   			return "";
   		}
   		
   	}
   	
   	
   	function getProfileURL($id, $thumb = false, $root = false)
   	{
   		if( $thumb )
   			$url = 'profile'. DS . 'thumb' . DS . $id .'.png';
   		else
   			$url = 'profile'. DS . 'main' . DS . $id .'.png';
   			 
   		if( $root )
   		{
   			$url = WWW_ROOT . $url;
   		}
   			
   		return $url;
   	}
   		
   function url_exists($url){
   		try {
        if (@fopen($url, "r")) 
			return true;
		else
			return false;
		}
		catch (Exception $e) {
			return false;
		}
    }    
    
   	function getPic($user)
   	{
   		$url = $this->getProfileURL($user['id'], false , false);
   		
   		if( file_exists( '/home/downshif/public_html/services/webroot/images/' . $url) )
   		{
   			return '<img class="profile" alt="" src="' . Configure::read('user_image_url') . $url .'"/>';
   		}
   		else if( $user['fbid'] != 0)
   		{
   			return '<fb:profile-pic uid="' . $user['fbid'] . '" facebook-logo="true" linked="false" size="normal" width="200"></fb:profile-pic>';
   		}
   		else
   		{
   			return '<img class="profile" alt="" src="http://www.todayhistory.net/webroot/img/anon.png"/>';
   		}
   	}
   		
   	function getThumbnail($user)
   	{
   		$url = $this->getProfileURL($user['id'], true , false);
   			
   		if( file_exists( '/home/downshif/public_html/services/webroot/images/' . $url) )
   		{
   			return '<img class="profile" alt="" src="' . Configure::read('user_image_url') . $url .'"/>';
   		}
   		else if( $user['fbid'] != 0)
   		{
   			return '<fb:profile-pic uid="' . $user['fbid'] . '" facebook-logo="true" linked="false" size="square"></fb:profile-pic>';
   		}
   		else
   		{
   			return '<img class="profile" alt="" src="http://www.todayhistory.net/webroot/img/anon_mini.png"/>';
   		}
   	}
   		
   	function getBySearch($searchText, $search = null) {
   		$params = array(
		'fields' => $this->fields,
		'conditions' => array('User.admin' => 0,
							   'or' => array(
							   				"User.name LIKE" => "%" . $searchText ."%",
							   				"User.username LIKE" => "%" . $searchText ."%",
							   				"User.email LIKE" => "%" . $searchText ."%")
						),
		'order' => 'User.id desc'
		);
		
		if(!$search)
   			$params['limit'] = 20;
   			
   		return $params;
	}
	
	function getName($user)
	{
		if($user['name'] == "")
			$name = $user['username'];
		else
			$name = $user['name'];
			
		return ucfirst($name);
	}
	
	function getProperName($user)
	{
		if($user['name'] == "")
			return $user['username'];
		else
			return $user['name'] . "(" . $user['username'] . ")";
	}
}
?>
