<?php
class Application extends AppModel {
	var $name = 'Application';
	var $displayField = 'name';
	
	//The Associations below have been created with all possible keys, those that are not needed can be removed
}
?>