<?php
   class ProjectFile extends AppModel {	

    	var $name = 'ProjectFile';
    	
    	var $belongsTo = array(
			'User' => array('className' => 'User',
								'foreignKey' => 'user_id',
								'conditions' => '',
								'fields' => '',
								'order' => ''
			));
	}

?>