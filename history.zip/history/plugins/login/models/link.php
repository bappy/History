<?php
class Link extends AppModel {

	var $name = 'Link';

	var $validate = array(
		'name' => array('notempty'),
		'url' => array(
			'notempty' => array(
				'rule' => 'notempty',
				'message' => 'Must have a url'
			)
			,
			'url' => array(
				'rule' => array('url', true),
				'message' => 'Must be a valid url, ie. http://www.downshiftit.com'
			)
		)			
	);

	var $fields = array('Comment.id', 'Comment.comment', 'Comment.created',
    		'User.id', 'User.username', 'User.fbid');
	
	/*
	var $hasAndBelongsToMany = array('Event' => 
                     array('className'   => 'Event',
                           'joinTable' => 'events_links',
						  	'foreignKey' => 'link_id',
							'associationForeignKey' => 'event_id',
							'unique' => true,
							'type' => 'INNER'
              		 )   
	); 
	*/
	
	function getByID($id) {
		$this->recursive = 0;
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Comment.id' => $id)
		);

		return $this->find('first', $params);
	}
	
	function alreadySaved($url) {
	
		$results =  $this->query("SELECT * from links WHERE links.url = '" . $url . "'");
		
		if( count( $results ) != 0)
		{
			return $results[0]['links'];
		}
		
		return false;
	}
}
?>
