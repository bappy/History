<?php
class Headline extends AppModel {
	var $name = 'Headline';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Event' => array(
			'className' => 'Event',
			'foreignKey' => 'headline_quote_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Category' => array(
			'className' => 'Category',
			'foreignKey' => 'category_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);


    var $validate = array(
        'headline_quote_id' => array(
            'rule' => 'notEmpty',
            'message' => 'Headline Required'
        )
    );

}
