<?php
class HeadlineQuote extends AppModel {
	var $name = 'HeadlineQuote';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $hasMany = array(
		'Headline' => array(
			'className' => 'Headline',
			'foreignKey' => 'headline_quote_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);


var $validate = array(

    'quote' => array(
        'rule' => 'notEmpty',
            'message' => 'Quotes Required'
        ),
        'author_name' => array(
            'rule' => 'notEmpty',
            'message' => 'Author Name Required'
        ),
    'link' => array(
        'rule' => 'notEmpty',
            'message' => 'Links Required'
        )
) ;



}
