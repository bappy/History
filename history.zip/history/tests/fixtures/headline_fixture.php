<?php
/* Headline Fixture generated on: 2012-08-12 08:13:27 : 1344759207 */
class HeadlineFixture extends CakeTestFixture {
	var $name = 'Headline';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'headline_quote_id' => array('type' => 'integer', 'null' => true, 'default' => NULL, 'length' => 200),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_general_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'headline_quote_id' => 1
		),
	);
}
