<?php
/* HeadlineEvent Fixture generated on: 2012-08-12 08:13:14 : 1344759194 */
class HeadlineEventFixture extends CakeTestFixture {
	var $name = 'HeadlineEvent';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'event_id' => array('type' => 'integer', 'null' => true, 'default' => NULL, 'length' => 20),
		'order' => array('type' => 'integer', 'null' => true, 'default' => NULL, 'length' => 20),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_general_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'event_id' => 1,
			'order' => 1
		),
	);
}
