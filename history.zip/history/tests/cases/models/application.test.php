<?php
/* Application Test cases generated on: 2012-08-12 08:12:57 : 1344759177*/
App::import('Model', 'Application');

class ApplicationTestCase extends CakeTestCase {
	var $fixtures = array('app.application', 'app.category');

	function startTest() {
		$this->Application =& ClassRegistry::init('Application');
	}

	function endTest() {
		unset($this->Application);
		ClassRegistry::flush();
	}

}
