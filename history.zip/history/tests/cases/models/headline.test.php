<?php
/* Headline Test cases generated on: 2012-08-12 08:13:27 : 1344759207*/
App::import('Model', 'Headline');

class HeadlineTestCase extends CakeTestCase {
	var $fixtures = array('app.headline', 'app.headline_quote');

	function startTest() {
		$this->Headline =& ClassRegistry::init('Headline');
	}

	function endTest() {
		unset($this->Headline);
		ClassRegistry::flush();
	}

}
