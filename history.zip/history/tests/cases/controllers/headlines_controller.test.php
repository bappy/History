<?php
/* Headlines Test cases generated on: 2012-08-12 13:21:05 : 1344777665*/
App::import('Controller', 'Headlines');

class TestHeadlinesController extends HeadlinesController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class HeadlinesControllerTestCase extends CakeTestCase {
	var $fixtures = array('app.headline', 'app.headline_quote');

	function startTest() {
		$this->Headlines =& new TestHeadlinesController();
		$this->Headlines->constructClasses();
	}

	function endTest() {
		unset($this->Headlines);
		ClassRegistry::flush();
	}

	function testIndex() {

	}

	function testView() {

	}

	function testAdd() {

	}

	function testEdit() {

	}

	function testDelete() {

	}

}
