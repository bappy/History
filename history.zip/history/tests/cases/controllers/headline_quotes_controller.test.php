<?php
/* HeadlineQuotes Test cases generated on: 2012-08-12 08:46:20 : 1344761180*/
App::import('Controller', 'HeadlineQuotes');

class TestHeadlineQuotesController extends HeadlineQuotesController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class HeadlineQuotesControllerTestCase extends CakeTestCase {
	var $fixtures = array('app.headline_quote', 'app.headline');

	function startTest() {
		$this->HeadlineQuotes =& new TestHeadlineQuotesController();
		$this->HeadlineQuotes->constructClasses();
	}

	function endTest() {
		unset($this->HeadlineQuotes);
		ClassRegistry::flush();
	}

	function testIndex() {

	}

	function testView() {

	}

	function testAdd() {

	}

	function testEdit() {

	}

	function testDelete() {

	}

}
