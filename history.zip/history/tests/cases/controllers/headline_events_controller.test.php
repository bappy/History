<?php
/* HeadlineEvents Test cases generated on: 2012-08-12 08:13:15 : 1344759195*/
App::import('Controller', 'HeadlineEvents');

class TestHeadlineEventsController extends HeadlineEventsController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class HeadlineEventsControllerTestCase extends CakeTestCase {
	var $fixtures = array('app.headline_event', 'app.event', 'app.user', 'app.category', 'app.application', 'app.headline');

	function startTest() {
		$this->HeadlineEvents =& new TestHeadlineEventsController();
		$this->HeadlineEvents->constructClasses();
	}

	function endTest() {
		unset($this->HeadlineEvents);
		ClassRegistry::flush();
	}

	function testIndex() {

	}

	function testView() {

	}

	function testAdd() {

	}

	function testEdit() {

	}

	function testDelete() {

	}

}
