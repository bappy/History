<?php
/* /app/views/helpers/link.php (using other helpers) */
class EUtilityHelper extends AppHelper {
    var $helpers = array('Html','CustomDate',"Form");

    function jqueryTabs($image_link,$width='',$height='',$alt,$tabs) {

        ?>

        <?php
        echo $this->Html->link(
            $this->Html->image($image_link, array("alt" =>$alt, "width" =>$width,"height"=>$height)),
            $tabs,
            array('escape' => false)
        );

        ?>




    <?php
    }

    function jquerySortable($events,$sortable,$cat,$day='',$month='')
    {
        $top=30;
        ?>
    <ul id="<?php echo $sortable;?>">
        <?php

        $i = 0;
        $k = 1;
        $C_today='';
        foreach ($events as $event) {
            $Y=$event["Event"]["year"];

//            $C_today=date('F j, Y',mktime(0, 0, 0, date($month)  , date($day), date($Y)));
  //              $C_today.=$Y;

            if($event["Event"]["category_id"]==39)
            {

                ?>


                    <li class="ui-state-default" id="sortable_<?php echo $event["Event"]["id"];?>"><div class="itemText"><strong><?php   echo $event["Event"]["name"];?></strong><?php if($event["Event"]["category_id"]==38){?><strong><?php   echo $event["Event"]["name"];?></strong>,<?php }?><?php echo  htmlspecialchars($event["Event"]["event"]); ?>
                <?php }
            else
            {

            $top=-17;
            ?>
             <li class="ui-state-default" id="sortable_<?php echo $event["Event"]["id"];?>"><div class="itemText"><?php if($event["Event"]["category_id"]==37){?><strong><?php   echo $event["Event"]["name"];?></strong>,<?php }?><?php if($event["Event"]["category_id"]==38){?><strong><?php   echo $event["Event"]["name"];?></strong>,<?php }?><?php echo  htmlspecialchars($event["Event"]["event"]); ?>
                <?php
                if($Y<0)
                {
                    $Y=$Y*(-1);
                    $Y=' '.$Y.' BC';

                    ?>

                <div id="dateDiv"><?php echo date('F j',mktime(0, 0, 0, date($event["Event"]['month'])  , date($event["Event"]['day']))).','.$Y;  ?></div>
              <?php }
                else if($Y>0)
                {
                ?>
                    <div id="dateDiv"><?php echo date('F j',mktime(0, 0,0, date($event["Event"]['month'])  , date($event["Event"]['day']))).', '.$event["Event"]["year"];  ?></div>
                 <?php }
                 else

            {
            ?>
            <div id="dateDiv"><?php echo date('F j',mktime(0, 0, date($event["Event"]['month'])  , date($event["Event"]['day'])));  ?></div>
            <?php }
            }
                ?>
               <Div style="float:right;position:relative;top:<?php echo $top; ?>px">
                <?php //echo $this->Html->link(__('Edit', true), array('action' => 'edit', $event['Event']['id']));

                echo $this->Html->image("images/edit.png", array(
                    "alt" => "Edit",
                    'url' => array('action' => 'edit', $event['Event']['id'])
                ));


                ?></Div></div>

            <?php

            echo "</li>";


        }

        ?>
    </ul>
   <?php }
function  tabs($events,$births,$deaths,$holidays,$day,$month)
{
    ?>        <div class="demo">

    <div id="tabs">
        <ul>
            <li><?php $this->jqueryTabs("images/event.gif",127,27,"event","#tabs-1")?></li>
            <li><?php $this->jqueryTabs("images/birth.gif",127,27,"birth","#tabs-2");?></li>
            <li><?php $this->jqueryTabs("images/death.gif",127,27,"death","#tabs-3");?></li>
            <li><?php $this->jqueryTabs("images/holiday.gif",127,27,"Holiday","#tabs-4");?></li>
        </ul>
        <div id="contab">
        <div id="tabs-1">
            <?php $this->jquerySortable($events,"sortable","36",$day,$month); ?>

        </div>

        <div id="tabs-2">
            <?php $this->jquerySortable($births,"sortable3","38",$day,$month); ?>
        </div>
        <div id="tabs-3">
            <?php $this->jquerySortable($deaths,"sortable4","37",$day,$month); ?>
        </div>

        <div id="tabs-4">
            <?php $this->jquerySortable($holidays,"sortable4","39",$day,$month); ?>
        </div>
        </div>
    </div>
</div>


<?php
}




function select_Date($month,$day)
{?>
<div id="dateSelect">


    <div class="formTitle">
        <br>


    </div>
    <!---formTitle finish-->
    <div id="dateField">

        <div id="mainselection">
            <?php
            $this->CustomDate->Month($month);
            ?>


        </div>

        <div id="mainselection2">
            <?php $this->CustomDate->Day($day);
            ?>
        </div>
        <div id="aload" style="display:none;">Working............</div>
        <span id="dload"></span>

    </div>
    <!---dateField finish-->


</div>

<?php }

    function input_field($author_name='',$quote='',$link='Wikipedia Link',$src="")
    {
       if($author_name=='')
           $author_name='Enter name of author';
        if($quote=='')
            $quote='Enter the quote';
        if($link=='')
            $link='Wikipedia Link';
        ?>
    <div class="inputField">

    <div class="inputWrap">

        <div id="author">

            <?php


                if($author_name<>'Enter name of author')
                {

            echo $this->Form->input('author_name', array("value" => $author_name,"label"=>false,"size"=>62,"width"=>"5",
            "onfocus"=>"$('#HeadlineQuoteAuthorName').css('color','black');"

            ));
                }
               else
               {

                   echo $this->Form->input('author_name', array("value" => $author_name,"label"=>false,"size"=>62,"width"=>"5",
                       "onfocus"=>"if(this.value=='Enter name of author'){this.value='', $('#HeadlineQuoteAuthorName').css('color','black');}",
                       "onblur"=>"if(this.value==''){this.value='Enter name of author'}"
                   ));

               }

            ?>

        </div>
        <!---author finish-->

        <div id="enterQute">
            <?php

                            /*if($quote<>"Enter the quote")
                            {

                            echo $this->Form->textarea('quote', array("value" => $quote,'escape' => false,"label"=>false,
                             "cols"=>62,"rows"=>5,
                             "onfocus"=>"if(this.value=='Enter the quote')this.value='',$('#HeadlineQuoteQuote').css('color','black')",
                             "onblur"=>"(this.value='".$quote."')"

                         ));
                            }
                                else
                                {
                                    echo $this->Form->textarea('quote', array("value" => $quote,'escape' => false,"label"=>false,
                                        "cols"=>62,"rows"=>5,
                                        "onfocus"=>"if(this.value=='Enter the quote')this.value='',$('#HeadlineQuoteQuote').css('color','black');"


                                    ));


                                }
                            */


            if($quote<>'Enter the quote')
            {

                echo $this->Form->textarea('quote', array("value" => $quote,"label"=>false,"cols"=>62,"rows"=>5,
                    "onfocus"=>"$('#HeadlineQuoteQuote').css('color','black');"

                ));
            }
            else
            {

                echo $this->Form->textarea('quote', array("value" => $quote,"label"=>false,"cols"=>62,"rows"=>5,
                    "onfocus"=>"if(this.value=='Enter the quote'){this.value='', $('#HeadlineQuoteQuote').css('color','black');}",
                    "onblur"=>"if(this.value==''){this.value='Enter the quote'}"
                ));

            }

            ?>


        </div>
        <!---enterQute finish-->

        <div id="wiki">
            <div>

                <?php
                echo $this->Form->input('link', array("value" => $link,"label"=>false,"size"=>"50", "id"=>"inputString","div"=>false,
                    "onkeyup"=>"lookup(this.value);",
                    "onblur"=>"fill(this.value);",
                   "onfocus"=>"if(this.value=='Wikipedia Link'){this.value=''}"



                ));
                ?>


                <!--<input  type="text"   name="data[HeadlineQuote][link]" size="80" value="<?php echo $link;?>"   id="inputString" onkeyup="lookup(this.value);" onblur="fill();" />-->
            </div>

            <div class="suggestionsBox" id="suggestions" style="display: none;">
                <!--<img src="upArrow.png" style="position: relative; top: -12px; left: 30px;" alt="upArrow" />-->
                <div class="suggestionList" id="autoSuggestionsList">

                </div>
            </div>
            <?php
            if(empty($src))

                $src=$this->webroot.'img/imgh.png';
?>
             <img  border="" src="<?php echo $src; ?>" id="wikipedia_src" width="40px" height="48px"
                 style="float: right;position:relative;top:-34px">




            <!---wiki finish-->

        </div>


    </div>
    <!---inputWrap finish-->

    <div   class="update"><?php  echo $this->Form->submit('images/update.gif', array("div" => false)); //
        echo $this->Form->end(); ?></div>

    </div>

    <?php }
    function  headline($event_headline='',$day='',$month='')
    {
        ?>
    <div class="inputField">
        <div id="inputHeadings">

            <?php
            $q = '';
            $val = '';
            $qt = "";

            $counter = 0;
            ?>
            <ul id="sortable2">
                <?php
                foreach ($event_headline as $e_head) {

                    $counter++;
                    if (isset($e_head["Headline"]["headline_quote_id"])) {
                        $q = $e_head["Headline"]["headline_quote_id"];
                        $qt .= $q . ':';
                        $val = $this->requestAction('/Headlines/index/' . $q);

                        // echo '<li>'.$val.'</li>';

                        ?>

                        <li id='sortable2_<?php echo $q;?>' class="ui-state-highlight"><span
                            class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                            <div  class="itemText"><?php echo $val?></div></li>



                        <?php
                    }


                }


                ?>
            </ul>
            <?php
            echo $this->Form->hidden("day", array("value" => $day));
            echo $this->Form->hidden("month", array("value" => $month));
            echo $this->Form->hidden('headline_quote_id', array("id" => "headline_quote_id"));
            echo $this->Form->hidden('category_id', array("id" => "category_id", "value" => 36));//event
            //echo $this->Form->textarea('headline_quote',array("cols"=>"10","rows"=>"5","id"=>"headline_quote","value"=>$val));
            ?>
            <input type="hidden" value="<?php echo rtrim($qt, ':');?>" id="HeadlineCateogry"
                   name="data[Headline][category]">


        </div>
        <!---inputWrap finish-->

        <div  class="update"><?php  echo $this->Form->submit('images/update.gif', array("div" => false, "class" => "update2"));
            echo $this->Form->end();
            //echo $this->Form->end(__('Update', true)); ?>
        </div>


    <?php }

    }
?>
